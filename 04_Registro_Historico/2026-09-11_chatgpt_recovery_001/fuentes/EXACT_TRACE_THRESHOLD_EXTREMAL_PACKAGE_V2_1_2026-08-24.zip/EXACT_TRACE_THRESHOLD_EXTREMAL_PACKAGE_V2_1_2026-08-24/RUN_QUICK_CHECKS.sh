#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/code/original_paper_iiii"
python src/verify_hashes.py
cd "$ROOT"
python code/reconstructed/exceptional_bridge_certificate.py
python code/reconstructed/connectivity_strip_certificate.py
python code/reconstructed/rectilinear_low_turn_scan.py
python code/reconstructed/determinant_singleton_search.py
python code/reconstructed/triangular_strip_regression.py
python code/reconstructed/phase6_four_link_scan.py
echo PACKAGE_V2_1_QUICK_CHECKS_PASS
