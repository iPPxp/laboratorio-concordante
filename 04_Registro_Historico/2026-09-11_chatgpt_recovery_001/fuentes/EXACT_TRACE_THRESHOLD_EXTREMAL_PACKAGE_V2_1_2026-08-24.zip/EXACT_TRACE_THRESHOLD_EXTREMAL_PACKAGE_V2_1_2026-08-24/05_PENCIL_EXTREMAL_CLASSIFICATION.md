# Pencil Extremal Classification — Final Audited Status

For

\[
U_J=\{(1,0),(0,1)\}\cup\{(1,k):k\in J\},
\]

the threshold and threshold-intensity classifications are now both closed:

| Pencil `J` | `tau_H` | `eta=gamma(tau)` | Status |
|---|---:|---:|---|
| `emptyset` | 4 | 1 | PROVED_AFTER_REPAIR |
| `{1}` | 3 | `2/3` | PROVED_AFTER_REPAIR |
| `{1,2}` | 3 | 1 | PROVED_AFTER_REPAIR |
| every other finite `J` | 2 | 1 | PROVED_AFTER_REPAIR |

Hence

\[
\boxed{
(\tau,\eta)(U_J)=
\begin{cases}
(4,1),&J=\varnothing,\\
(3,2/3),&J=\{1\},\\
(3,1),&J=\{1,2\},\\
(2,1),&\text{otherwise}.
\end{cases}}
\]

## 1. Intensity one outside the unit triangular pencil

The single-rung families from Phases 3–4 give `K_H=|S|-O_J(1)` at threshold for every `J != {1}`. In particular:

- `J=emptyset`: improved rectilinear ladder;
- `J={1,2}`: threshold-3 single-rung family with `K_H=|S|-2`;
- `1 notin J`: maximal-slope rails plus a cap yield one horizontal rung family;
- `1 in J`, `max J=K>=3`: the `d_1`-rail construction has a forced finite prefix followed by a single-rung alternating core, with exact
  \[
  K_H=|S|-K-1.
  \]

Thus `eta=1` in every one of these classes.

## 2. Unit triangular pencil

Let

\[
U_1=\{(1,0),(0,1),(1,1)\}.
\]

The repaired threshold theorem gives

\[
\tau_H(U_1)=3.
\]

The explicit threshold-3 family has a triangular-strip core and therefore gives the lower bound

\[
\eta(U_1)\ge2/3.
\]

Phase 5 identified the missing issue: a free witness at budget three may have four links, so the earlier three-link reduction did not prove a universal upper bound. Phase VI closes this gap by the Four-Link Unit-Triangular Reduction Theorem:

\[
\boxed{
K_{\rm free}(S;U_1)\le3
\Rightarrow
K_H(S;U_1)\le\frac23|S|+O(1).
}
\]

The proof uses support-line sparsity for nonparallel pairs, uniqueness of an unbounded adjacent parallel pair, reduction to one bounded-port triangular core, and the v2.1 12-state connectivity-aware strip transfer certificate.

Consequently

\[
\boxed{\eta(U_1)=2/3.}
\]

The earlier `CONJECTURE` status is superseded.
