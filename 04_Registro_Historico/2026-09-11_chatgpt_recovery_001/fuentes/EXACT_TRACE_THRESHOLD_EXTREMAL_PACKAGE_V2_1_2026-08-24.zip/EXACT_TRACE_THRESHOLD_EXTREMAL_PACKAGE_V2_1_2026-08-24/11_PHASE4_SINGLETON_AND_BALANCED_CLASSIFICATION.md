# Phase 4 — Singleton and Balanced Classification — v2.1 referee repair

## 4.1 Singleton Determinant Theorem

For a finite primitive direction set define
\[
m_r(\delta)=\#\{q\ne r:|\det(r,q)|=\delta\}.
\]
If no singleton class exists, a globally maximal determinant pair forces a balanced triangle `u,v,u+v`.  The hexagonal norm
\[
\rho(a,b)=\max\{|a|,|b|,|a-b|\}
\]
and the contraction
\[
|\det(z,x)|\le D(z)D(x)/M
\]
prevent an exterior maximum from being repeated. Hence
\[
\boxed{|U|\ge4\Rightarrow\text{a singleton determinant class exists}.}
\]
The only nontrivial no-singleton sets are determinant-balanced triples.

## 4.2 Nonhorizontal Singleton Bridge

If `r,q` are nonhorizontal and `q` is the unique direction in its determinant class relative to `r`, two parallel `r`-rails separated by `q` have one rung family.  The explicit two-turn exterior witness has exact trace equal to the rails and the confined graph is a forced single-rung ladder with only `O_U(1)` straight vertices. Thus
\[
\boxed{(\tau,\eta)=(2,1).}
\]

## 4.3 Horizontal + balanced triple

The residual four-direction form is
\[
U=\{h,q,t,r=q+t\},\qquad D=|\det(q,t)|.
\]
Divisibility of one of `q_y,t_y,r_y` by `D` implies divisibility of all three. Writing normalized heights `a,b,a+b`:

- `a=b=1`: the `U_{1,2}` class, `(3,1)`;
- `a+b>=3`: a two-turn single-rung construction gives `(2,1)`;
- nondivisible heights: every threshold-two unbounded core is a triangular interval strip up to `O_U(1)` end pieces.

The last branch is completed by the connectivity-aware strip transfer lemma below; no unlisted end-splice assumption remains.

## 4.4 Two triangular-strip results — keep them distinct

### Exact terminal-constrained canonical theorem

For the canonical strip with the terminal states/endpoints forced by the extremal gadget,
\[
\boxed{K_H^{\rm term}(T_n)=\left\lfloor\frac{2|V(T_n)|}{3}\right\rfloor.}
\]
This is the Phase-5 four-state exact theorem.  It is **not** the unrestricted free-endpoint optimum of the bare strip.

### Connectivity-aware transfer theorem

For arbitrary feasible boundary connectivity, use the 12-state frontier automaton of v2.1.  A cut has three possible crossing edges `a,b,c`; a state records their set together with their pairing through the processed prefix and attachment to zero, one, or two global endpoints.  There are exactly 12 possible nonfinal states and 17 local transitions.

If `A` is its max-plus transfer matrix, the finite certificate proves
\[
\operatorname{supp}(A^6)\subseteq\operatorname{supp}(A^3),
\qquad
A^6\ge A^3+2
\]
on every finite entry of `A^3`.  Base lengths `0,...,5` then give, for every feasible state pair,
\[
F_n\ge\frac{2n}{3}-\frac73,
\]
where `F_n` is the maximum number of straight rail vertices in an `n`-column transfer preserving the full boundary connectivity state.  Hence a clean slab on `2n` vertices has a replacement with
\[
K\le\frac23(2n)+\frac73.
\]
Because the state records pairing/connectivity, substituting a transfer with the same initial and terminal states preserves the global Hamiltonian path and cannot create a closed cycle.

The proof certificate is `code/reconstructed/connectivity_strip_certificate.py` with state and transition tables in `data/connectivity_strip_states.csv` and `data/connectivity_strip_transitions.csv`.

Therefore the bounded end pieces in the nondivisible branch cost only `O_U(1)`, while every long triangular slab has coefficient at most `2/3`.  The explicit threshold family supplies the matching lower bound, so
\[
\boxed{\text{nondivisible horizontal+balanced branch has }(\tau,\eta)=(2,2/3).}
\]

## 4.5 Distinguished singleton reduction

Fix a distinguished direction `e`.  The maximum-determinant graph reduction shows that if `|U|>=5` and no singleton avoids `e`, the only residual form is
\[
U=\{e,r\}\cup\bigcup_i\{x_i,r-x_i\}.
\]

## 4.6 Paired-star parity collapse

Each class `d_i=|det(r,x_i)|` is odd.  With largest class `D` and smaller class `d`, a distinct non-`e` repeater would require class `D-d` (even) or `D+d>D`, both impossible.  The distinguished direction can hide at most one of the two cross values, so another singleton avoids `e`. Thus
\[
\boxed{|U|\ge5\Rightarrow\forall e\in U\ \exists r,q\ne e:\ m_r(|\det(r,q)|)=1.}
\]
Taking `e=h` and applying 4.2 gives
\[
\boxed{|U|\ge5\Rightarrow(\tau,\eta)=(2,1).}
\]
