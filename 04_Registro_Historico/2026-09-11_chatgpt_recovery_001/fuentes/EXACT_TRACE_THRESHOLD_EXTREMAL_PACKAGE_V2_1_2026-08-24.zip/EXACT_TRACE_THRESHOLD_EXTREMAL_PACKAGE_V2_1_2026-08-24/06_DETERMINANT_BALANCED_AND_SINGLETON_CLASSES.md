# Determinant-Balanced Triples and Singleton Determinant Classes — Final Status

## 1. Balanced triples

A triple

\[
U=\{u,v,w\}
\]

is determinant-balanced when

\[
|\det(u,v)|=|\det(v,w)|=|\det(w,u)|=D>0.
\]

After sign choices one has

\[
\boxed{w=u+v.}
\]

Indeed, equality of the first two determinants gives `w-v=ku`; the third determinant forces `|k|=1`.

Balanced triples are exactly the nontrivial alphabets with no singleton determinant class.

## 2. Singleton Determinant Theorem

For

\[
m_r(\delta)=\#\{q\in U\setminus\{r\}:|\det(r,q)|=\delta\},
\]

Phase 4.1 proves:

\[
\boxed{
|U|\ge4\Rightarrow\exists r,\delta\text{ with }m_r(\delta)=1.
}
\]

More precisely, for `|U|>=2`, absence of every singleton class occurs iff `|U|=3` and the triple is determinant-balanced.

The proof takes a globally maximal determinant `M`. Any repeated maximal class forces, after signs, `w=u+v`; the maximal component is a balanced triangle. Exterior directions are controlled by the hexagonal norm

\[
\rho(a,b)=\max\{|a|,|b|,|a-b|\},
\]

which yields a determinant contraction contradiction if every exterior maximum were repeated.

## 3. Nonhorizontal singleton bridge

If `r,q` are both nonhorizontal and `q` is the unique representative of its determinant class relative to `r`, then the generic two-rail construction collapses to one cross family. It gives

\[
K_{\rm free}=2,
\qquad
K_H=|S|-O_U(1),
\]

hence

\[
\boxed{(\tau_H(U),\eta(U))=(2,1).}
\]

The older unqualified phrase “singleton implies eta=1” is superseded by this host-compatible formulation.

## 4. Horizontal plus balanced triple

The only four-direction obstruction to an immediate nonhorizontal singleton has the form

\[
U=\{h,q,t,r\},\qquad r=q+t,
\]

where `h` is horizontal and the three nonhorizontal directions are balanced with

\[
D=|\det(q,t)|.
\]

Divisibility is all-or-none across the three heights.

### Divisible branch

Write

\[
q_y=aD,\qquad t_y=bD,\qquad r_y=(a+b)D,
\]

with `gcd(a,b)=1`.

- If `a=b=1`, the alphabet is the pencil `U_{1,2}` in sublattice coordinates: `(tau,eta)=(3,1)`.
- If `a+b>=3`, a two-turn single-rung cap construction gives `(tau,eta)=(2,1)`.

### Nondivisible branch

If `D` divides none of the three heights, every threshold-2 amplifying three-link core reduces, up to `O_U(1)` terminal pieces, to a triangular strip. The connectivity-aware strip transfer theorem (with the terminal-constrained exact theorem supplying the sharp lower gadget) then gives

\[
\boxed{(\tau,\eta)=(2,2/3).}
\]

## 5. Distinguished Singleton Theorem

For any distinguished direction `e`, Phase 4.5–4.6 proves

\[
\boxed{
|U|\ge5\Rightarrow
\exists r,q\in U\setminus\{e\}
:\ m_r(|\det(r,q)|)=1.
}
\]

The reduction is via the maximum-determinant graph. If no useful singleton is found immediately, the only possible residual form is a paired star

\[
U=\{e,r\}\cup\bigcup_i\{x_i,r-x_i\}.
\]

For each pair,

\[
d_i=|\det(r,x_i)|
\]

is odd: if it were even, `x_i` and `r-x_i` would agree modulo 2 and primitive `r` would be even. Choosing maximal `D` and smaller odd `d`, any nontrivial repeater of a cross determinant would require the difference class `D-d`, which is even and therefore unavailable. Since `e` can hide at most one of two distinct cross values, an `e`-avoiding singleton is forced.

Taking `e=h` gives

\[
\boxed{|U|\ge5\Rightarrow(\tau,\eta)=(2,1).}
\]

## 6. Balanced intensity

The balanced-triangular mechanism is now fully resolved:

- balanced triple containing the horizontal: equivalent to the unit triangular pencil, `(tau,eta)=(3,2/3)`;
- balanced triple without the horizontal: determinant-generic, `(tau,eta)=(2,2/3)`;
- horizontal plus balanced triple, nondivisible heights: `(2,2/3)`;
- horizontal plus balanced triple, divisible heights: intensity `1` as above.

Thus `2/3` is not an empirical anomaly. It is the exact Hamiltonian-turn density of the triangular-strip obstruction.
