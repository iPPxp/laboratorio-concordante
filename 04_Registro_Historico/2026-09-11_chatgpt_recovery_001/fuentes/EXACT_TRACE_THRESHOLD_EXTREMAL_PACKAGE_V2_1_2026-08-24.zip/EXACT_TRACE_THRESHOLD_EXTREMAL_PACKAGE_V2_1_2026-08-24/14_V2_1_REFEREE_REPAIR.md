# v2.1 Referee Repair — Extreme-RAG Closure

## Verdict

The extreme post-v2 audit identified two proof-completeness debts rather than counterexamples:

1. exceptional-pencil low-two-turn clipping referred to an unwritten finite boundary bridge case split;
2. the Phase-VI bounded-port strip replacement tracked cut parity but not path connectivity/pairing.

v2.1 replaces both with explicit finite certificates.

## Repair A — exceptional boundary bridges

`code/reconstructed/exceptional_bridge_certificate.py` enumerates every determinant-permitted nonhorizontal rail/connector case for `U_1` and `U_{12}`, including both first-host residues of `d_2` rails.  Every case has a permitted primitive shortcut between first-host rail entries.  For `U_1`, `ell=1`; for `U_{12}`, `ell<=2`, and the only possible visible connector interior consists of one vertex.  The human table and argument are in Phase 2; the exact table is `data/exceptional_bridge_table.csv`.

This closes the formal lower-threshold bridge debt for
\[
\tau(U_1)=\tau(U_{12})=3.
\]

## Repair B — connectivity-aware triangular transfer

The old four-state automaton remembers crossing parity but not which crossing edges are already connected through the processed prefix.  It is sufficient for the canonical fixed-terminal exact calculation but not, by itself, for arbitrary slab replacement.

The new frontier state records crossing set, pairing, and attachment to global endpoint labels.  Completeness of the 12-state list follows from the fact that the processed prefix of a Hamiltonian path is a linear forest and every component has exactly two terminals among crossing stubs and global endpoints.

The local degree equations enumerate every transition.  Premature closed components and endpoint-to-endpoint closure are forbidden.  This yields 17 transitions.

Let `A` be the max-plus transition matrix.  The finite machine certificate verifies
\[
\operatorname{supp}(A^6)\subseteq\operatorname{supp}(A^3),\qquad A^6\ge A^3+2.
\]
Together with bases `n=0,...,5`, this proves
\[
F_n(s,t)\ge 2n/3-7/3
\]
for every feasible state pair.  Consequently every clean triangular slab admits a replacement preserving the exact boundary connectivity with turn cost at most `2/3` of its vertices plus a constant.

This closes both:

- the arbitrary-port Four-Link Unit-Triangular Reduction;
- the finite end-splice debt in the threshold-two balanced triangular reductions.

## Re-freeze rule

The global `(tau,eta)` classification is re-frozen in v2.1 only because both RAG-extreme objections now have explicit finite proof certificates.  Computation-only scans remain labelled as regression evidence and are not used as universal proofs.
