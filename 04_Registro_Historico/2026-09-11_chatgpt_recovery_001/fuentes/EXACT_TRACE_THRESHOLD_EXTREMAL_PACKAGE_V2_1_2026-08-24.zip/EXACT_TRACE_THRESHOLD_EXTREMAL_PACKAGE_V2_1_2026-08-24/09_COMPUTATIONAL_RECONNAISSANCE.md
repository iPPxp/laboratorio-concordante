# Computational Reconnaissance

Computation is used as a regression/adversarial check, not as a substitute for proof.

## 1. Original Paper IIII reproducibility package recovered

`code/original_paper_iiii/` is the recovered Online Resource 1 (`ESM_1.zip`) rather than a reconstruction. It contains:

- the primitive-step exact-trace implementation;
- exact finite-instance turn solver using 0-1 BFS over Hamiltonian DP states;
- dense-family generator and validators;
- structural and regression tests;
- original results tables;
- original SHA-256 manifest.

The manuscript itself states that these computations are regression controls and not ingredients of the universal proof.

## 2. Reconstructed post-Paper-IIII regression

`code/reconstructed/phase_chat_regression.py` was rebuilt from the formulas stated in the chat and is explicitly marked `RECONSTRUCTED FROM CHAT DESCRIPTION`.

It verifies, on finite instances:

| Family | Parameters checked | Result |
|---|---|---|
| Rectilinear threshold ladder | `t=3,5,7` | free witness valid; exact `K_H=2t` |
| Improved rectilinear extremal | `t=2,4,6` | free witness valid; exact `K_H=|S|-3` |
| `U_1` three-turn family | `n=2,...,12` | free witness valid; exact `K_H` recorded |
| `U_{12}` extremal | `p=2,4,6` | exact `K_H=|S|-2` |
| `U_{23}` extremal | `p=2,4,6` | exact `K_H=|S|-2` |
| `U_{m,m+1}` extremal | `m=2,3,4`, `p=2,4` | exact `K_H=|S|-2` |
| Repaired top-gap | several `J`, `p=2,4,6` | exact stated formulas in tested cases |
| Full initial block | `K=3,4` admissible parities | free witness valid; linear exact `K_H` |

Outputs: `data/phase_chat_regression.csv` and `.json`.

## 3. Unit triangular family DP pattern

For the `U_1` three-turn family, parameter `n=2,...,12` yields exact confined optima

| `n` | `|S|=2n+6` | exact `K_H` |
|---:|---:|---:|
| 2 | 10 | 5 |
| 3 | 12 | 8 |
| 4 | 14 | 9 |
| 5 | 16 | 9 |
| 6 | 18 | 12 |
| 7 | 20 | 13 |
| 8 | 22 | 13 |
| 9 | 24 | 16 |
| 10 | 26 | 17 |
| 11 | 28 | 17 |
| 12 | 30 | 20 |

From `n=3` onward the increments repeat `+1,0,+3` cyclically (equivalently a period-three affine pattern), compatible with asymptotic density `2/3`. These values are now regression support for the independently proved `eta(U_1)=2/3`; they are not used as the proof.

## 4. Standardized rectilinear low-turn scan

`code/reconstructed/rectilinear_low_turn_scan.py` uses a fully documented enumeration convention:

- simple rectilinear compressed paths;
- 1–4 links;
- each run length at most 3;
- start `x=0`, start height in `[-3,3]`;
- horizontal translation normalization of host traces.

Results:

- 5,072 distinct normalized traces;
- 4,908 admissible traces;
- admissible counts by minimum generated witness turns `k=0,1,2,3`: `25,144,800,3939`;
- maximum exact `K_H` in those four groups: `0,1,2,3`;
- no `K_H>k` violation found.

Outputs: `data/rectilinear_low_turn_scan.json` and summary CSV.

### Earlier interactive counts

The chat also reported exploratory runs with different normalization/bounding conventions (including totals such as 9,004 and 20,254 traces and a larger run with group counts `[60,515,3739,23977]`). The original scripts for those interactive runs were not recovered and the counting conventions were not fully specified. They are therefore **not canonicalized** in this package. The standardized reconstructed scan above replaces them as the reproducible control.

## 5. Singleton determinant-class search

`code/reconstructed/determinant_singleton_search.py` enumerates all normalized primitive unoriented directions with infinity norm at most 5. It confirms there are 40 directions and checks:

- 91,390 four-subsets;
- 658,008 five-subsets.

Every tested set has a singleton determinant class. No finite counterexample was found.

Outputs: `data/determinant_singleton_summary.csv` and `.json`.

## 6. Proof status rule

The following may be supported by computation but are **not** proved by it:

- the universal rectilinear clipping theorem;
- `tau` classification;
- the universal determinant/singleton theorems;
- the terminal-constrained exact triangular-strip theorem;
- the Four-Link Unit-Triangular Reduction Theorem;
- the global `(tau,eta)` classification.


## 7. Post–Phase VI regression controls

Two additional reconstructed checks accompany v2:

- `triangular_strip_regression.py`: endpoint-constrained exact DP for canonical triangular strips, compared to `floor(2|V|/3)`;
- `phase6_four_link_scan.py`: finite exhaustive scan of four-link `U_1` witnesses under a documented small-length convention, recording exact confined turn cost for admissible traces.

The current v2 outputs are:

- terminal strip regression: exact agreement for `n=1,...,8`;
- four-link scan convention: link lengths `1..2`, start height `[-3,3]`, horizontal-translation normalization, at most 13 host vertices; 23,816 generated simple witnesses collapsed to 7,898 distinct traces, of which 7,731 were confined-admissible. The largest observed `K_H-2|S|/3` was `1/3`.

These checks are deliberately labeled regression only. The Four-Link Reduction Theorem is structural and does not depend on finite enumeration.


## 8. v2.1 proof certificates added after the extreme RAG

### Exceptional bridge certificate

`exceptional_bridge_certificate.py` exhausts the finite determinant-permitted boundary-entry cases for the two exceptional pencils.  It emits 22 table rows (including horizontal clipping rows), all passing.  This finite table is part of the proof of the local bridge lemma, not a large-N extrapolation.

### Connectivity-aware strip certificate

`connectivity_strip_certificate.py` constructs the complete 12-state/17-transition frontier automaton including pairing and global-endpoint attachments.  It verifies the finite max-plus certificate

- `support(A^6) subset support(A^3)`;
- `A^6 >= A^3 + 2` on every finite entry of `A^3`;
- worst base deficit over lengths `0,...,5` is `7/3`.

Those finite identities imply the all-length theorem algebraically.  The additional check through length 60 is regression only.
