# Source Provenance

## Primary prior mathematical source

Paper IIII: *Unbounded Exact-Trace Confinement Gaps for Finite-Direction Lattice Spanning Paths*, Jorge Rosales Pérez, DOI 10.5281/zenodo.22065177. The preserved Library TeX/PDF copies anchored the model, two-rail lemma, generic/pencil dichotomy, and original extremal open problem.

## Original code recovered

`ESM_1.zip` was recovered from the user's Library. Its contents are preserved under `code/original_paper_iiii/`. The files in `code/reconstructed/` are separate and explicitly marked as reconstructed or post-paper regression controls.

## Chat-derived mathematics

The threshold/extremal program was developed through Phases 1, 2, 2.2–2.4, RAG repairs, 3, 3.2–3.4, 4.1–4.6, Phase-5 global RAG, and Phase VI. Earlier unclosed or defective claims are not silently overwritten; their status transitions are recorded in `08_ADVERSARIAL_AUDIT.md` and `CLAIMS_MATRIX.csv`.

## Phase-5 and Phase-VI status

`12_PHASE5_GLOBAL_RAG_CLOSURE.md` preserves the moment when the global `(tau,eta)` classification was explicitly *not* frozen because the four-link unit-triangular upper bound was missing. `13_PHASE6_FOUR_LINK_UNIT_TRIANGULAR_CLOSURE.md` contains the later repair that closes that exact gap.

## Literature

`10_LITERATURE_POSITION.md` is the targeted literature review assembled before the Phase-VI closure. It remains useful for neighboring fields, but the new singleton/determinant and triangular-strip theorems require a fresh specialist novelty search before priority is claimed.


## v2.1 additions (2026-08-24)

- `15_RAG_EXTREMO_POST_V2.md`: preserved extreme post-v2 audit that revoked the parity-only bounded-port proof.
- `14_V2_1_REFEREE_REPAIR.md`: formal repair document responding to that audit.
- `connectivity_strip_certificate.py`: reconstructed finite-state proof certificate with connectivity/pairing state, created after the extreme audit.
- `exceptional_bridge_certificate.py`: reconstructed finite first-host bridge certificate for the two exceptional pencils.

These additions do not modify the original Paper IIII reproducibility package under `code/original_paper_iiii/`.
