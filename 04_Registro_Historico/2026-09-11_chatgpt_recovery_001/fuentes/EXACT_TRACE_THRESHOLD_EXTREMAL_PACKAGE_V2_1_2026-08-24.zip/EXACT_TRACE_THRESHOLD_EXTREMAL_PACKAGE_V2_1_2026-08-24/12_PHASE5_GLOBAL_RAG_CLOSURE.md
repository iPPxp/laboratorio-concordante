> **Historical audit snapshot.** This file intentionally preserves the Phase-5 pre-Phase-VI status. Later repairs are authoritative in `13_PHASE6_FOUR_LINK_UNIT_TRIANGULAR_CLOSURE.md` and `14_V2_1_REFEREE_REPAIR.md`.

# Historical status note

This document records the Phase-5 RAG at the moment when the four-link unit-triangular upper bound was still open. In v2, the strip formula written below as `K_H(T_n)` is refined to the endpoint/terminal-state constrained quantity `K_H^{term}(T_n)`; that notation repair was discovered during final package regression. Its non-freeze verdict is intentionally preserved as audit history. `13_PHASE6_FOUR_LINK_UNIT_TRIANGULAR_CLOSURE.md` supplies the missing theorem and supersedes only that final open-status conclusion.

---

# Phase 5 — Global Adversarial Audit and Closure Status

## Executive verdict

**DO NOT FREEZE the full global `(tau, eta)` classification yet.**

The threshold theory `tau_H(U)` survives the audit after a local repair of the exceptional low-two-turn clipping argument. The determinant-combinatorics chain (Phases 4.1, 4.2, 4.5, 4.6) also survives. The exact triangular-strip theorem survives, but its proof must be replaced by the four-state cut automaton given below.

The remaining substantive gap is the universal upper bound for the unit triangular pencil `U_{\{1\}}` at free budget 3. A free witness may then have four links, while the three-link reduction used in Phase 4.3 is insufficient. Thus the previously stated global conclusion `eta(U) in {2/3,1}` is **not yet frozen**.

The exact remaining target is

\[
K_{\rm free}(S;U_{\{1\}})\le 3
\quad\Longrightarrow\quad
K_H(S;U_{\{1\}})\le \frac23|S|+O(1).
\]

The existing extremal family gives the matching lower bound, so proving this implication would yield `eta(U_{\{1\}})=2/3` and complete the global classification.

---

## 1. Claims that survive

### 1.1 Baseline exact-trace model and Paper IIII theorem
Survives unchanged.

### 1.2 Universal one-turn obstruction
Survives:
\[
K_{\rm free}\le1\implies K_H=O_U(1).
\]

### 1.3 Rectilinear threshold
The Phase-1 clipping argument and the sharp ladder survive:
\[
\tau_H(U_\square)=4.
\]
The improved extremal rectilinear family also survives and gives `eta=1` at threshold.

### 1.4 Exceptional pencils `J={1}` and `J={1,2}`
The thresholds survive:
\[
\tau(U_{\{1\}})=3,
\qquad
\tau(U_{\{1,2\}})=3.
\]
The low-two-turn proof should be written using an explicit boundary-entry bridge lemma rather than the previous phrase “finite local case split”. For `U_{\{1\}}`, a direct rail edge forces connector length 1; clipping or boundary-entry bridging gives bounded confined cost. For `U_{\{1,2\}}`, connector length is at most 2; the only length-2 nonhorizontal danger uses `d_2` rails and a `v` or `d_1` connector, and the two rail-entry vertices are horizontally adjacent. If one connector interior vertex is visible, it forms a constant-size splice. Thus no free-two-turn amplifier exists.

### 1.5 Pencil threshold classification
The repaired top-gap theorem, consecutive-block theorem, full-initial-block construction, and coset normalization survive. Hence
\[
\tau_H(U_J)=
\begin{cases}
4,&J=\varnothing,\\
3,&J=\{1\}\text{ or }J=\{1,2\},\\
2,&\text{otherwise}.
\end{cases}
\]
Together with the Paper IIII generic/pencil dichotomy, the global `tau` classification survives.

### 1.6 Bounded-to-linear extremal jump
Survives conditionally on the now-audited `tau` classification:
\[
k<\tau\Rightarrow \Gamma_U(k,N)=O_{U,k}(1),
\qquad
k\ge\tau\Rightarrow \Gamma_U(k,N)=\Theta_U(N).
\]
The upper half is trivial; the lower half uses the explicit linear-size threshold families.

### 1.7 Single-rung extremal families
The sharp families for the rectilinear alphabet, `U_{12}`, `U_{23}`, and `U_{m,m+1}` survive. In each applicable family, degree propagation really forces all but `O_U(1)` internal vertices to turn, giving `eta=1`.

### 1.8 Singleton Determinant Theorem (Phase 4.1)
Survives:
\[
|U|\ge4\implies \exists r,\delta:\ m_r(\delta)=1.
\]
More precisely, among nontrivial alphabets the only sets with no singleton determinant class are determinant-balanced triples.

### 1.9 Nonhorizontal singleton bridge (Phase 4.2)
Survives. If `r,q` are nonhorizontal and `q` is the unique representative of its determinant class relative to `r`, the explicit two-rail construction gives
\[
K_{\rm free}=2,
\qquad
K_H=|S|-O_U(1),
\]
so
\[
(\tau,\eta)=(2,1).
\]

### 1.10 Divisible horizontal + balanced-triple branch (Phase 4.3)
Survives. Writing the balanced triple as `q,t,r=q+t` with `D=|det(q,t)|`, divisibility of one height by `D` implies divisibility of all three. If normalized heights are `aD,bD,(a+b)D`, then:
- `a=b=1` is the `U_{12}` class: `(tau,eta)=(3,1)`;
- `a+b>=3` has a two-turn single-rung family and `(tau,eta)=(2,1)`.

### 1.11 Distinguished Singleton Theorem (Phases 4.5–4.6)
Survives. The maximum-determinant graph reduction and the paired-star parity collapse are consistent and complete. For any distinguished direction `e`,
\[
|U|\ge5\implies \exists r,q\ne e:\ m_r(|\det(r,q)|)=1.
\]
Taking `e` to be the horizontal when present and applying Phase 4.2 gives
\[
\boxed{|U|\ge5\implies (\tau,\eta)=(2,1).}
\]

---

## 2. Repair of the exact triangular-strip theorem

Let `T_n` have vertices
\[
A_0,\ldots,A_n,
\qquad
B_0,\ldots,B_{n+1},
\]
rail edges on each row and cross edges `A_iB_i`, `A_iB_{i+1}`. Hamiltonian endpoints are `B_0,B_{n+1}`.

The previous “straight-conflict triangle” proof was incomplete. The theorem itself is correct and has a clean four-state proof.

For cut `i`, let `a_i,b_i` indicate whether rail edges `A_iA_{i+1}`, `B_iB_{i+1}` are used; set `a_n=0`. Let `c_i` indicate `A_iB_{i+1}`. Cut parity gives
\[
a_i+b_i+c_i\equiv1\pmod2,
\]
so `c_i=1` exactly when `a_i=b_i`.

Internal degree two yields the following allowed transitions for the cut state `(a_i,b_i)`:

```text
00 -> 00,10,11
01 -> 00,10,11
10 -> 01
11 -> 00,10
```

A straight vertex is earned only on

```text
01 -> 11   (one B-straight)
11 -> 10   (one A-straight)
```

and every other transition earns zero. The allowed initial states are `00,10,11`; allowed terminal states are `00,01`.

A max-plus induction gives the maximum number of straight internal vertices
\[
s_n=\left\lfloor\frac{2n-1}{3}\right\rfloor.
\]
Since `|V(T_n)|=2n+3`,
\[
K_H(T_n)
=2n+1-s_n
=\left\lfloor\frac{4n+6}{3}\right\rfloor
=\left\lfloor\frac{2|V(T_n)|}{3}\right\rfloor.
\]
The periodic snake realizes equality. Thus the canonical triangular-strip theorem is **PROVED_AFTER_REPAIR**.

---

## 3. Three-link triangular reduction

For a free witness with at most two turns:

1. if the first and third support lines are nonparallel, all three supports are pairwise nonparallel and there are only `O_U(1)` primitive inter-support edges; hence `K_H=O_U(1)`;
2. if the outer supports are parallel but there is no direct rail-to-rail edge, all transitions go through the middle support and again `K_H=O_U(1)`;
3. if a direct rail edge exists and the middle link has `ell` primitive steps in direction `q`, then
   \[
   |\det(r,w)|=\ell|\det(r,q)|,
   \]
   so `ell=O_U(1)`. Thus the middle trace is a bounded perturbation of two rail intervals.

For a determinant-balanced triple the relevant cross class consists of exactly two adjacent shifts, giving a triangular interval strip. The same is true in the nondivisible `horizontal + balanced triple` branch of Phase 4.3, except for the horizontal-middle-link case `ell=1`, which admits a bounded-turn boundary bridge and therefore does not amplify.

This repairs the **three-link** reduction used for threshold-2 balanced cases. A publication proof should include the finite end-splice table for interval strips, but there is no remaining structural obstacle in this branch.

---

## 4. The substantive remaining gap: `U_{\{1\}}`

The claim
\[
\eta(U_{\{1\}})=\frac23
\]
was promoted too early in Phase 4.4.

What is proved:
- `tau(U_{\{1\}})=3`;
- an explicit threshold-3 family has a triangular-strip core;
- the repaired strip theorem gives
  \[
  \eta(U_{\{1\}})\ge\frac23.
  \]

What is **not** proved:
- a universal upper bound over every admissible trace with `K_free<=3`.

At budget 3 a witness can have four links. The three-link reduction above does not cover four-link orientation patterns such as `ABCA`, `ABAC`, `ABAB`, and `ABCB`. Long two-link exterior detours can have determinant cancellation, so the connector lengths are not automatically `O_U(1)`.

The exact remaining theorem is therefore
\[
\boxed{
K_{\rm free}(S;U_{\{1\}})\le3
\implies
K_H(S;U_{\{1\}})\le\frac23|S|+O(1).
}
\]

A proof should classify the four orientation patterns and show that every unbounded instance decomposes into one or two adjacent triangular-rail strips plus straight tails / bounded junctions. This is plausible and supported computationally, but it has not yet been written at referee-proof level.

---

## 5. Correct current global map

All classes except the unit triangular pencil are now structurally classified.

Definitively established pairs include
\[
(4,1),\quad(3,1),\quad(2,1),\quad(2,2/3).
\]
For the unit triangular pencil define
\[
\eta_*:=\eta(U_{\{1\}}).
\]
Currently
\[
\boxed{\frac23\le\eta_*\le1.}
\]
Thus the audited global statement is
\[
(\tau,\eta)
\in
\{(4,1),(3,1),(2,1),(2,2/3),(3,\eta_*)\},
\qquad
\frac23\le\eta_*\le1.
\]

The formerly stated five-point classification with `(3,2/3)` is **CONDITIONAL** on the remaining four-link theorem.

---

## 6. Regression controls run during Phase 5

These are controls, not proofs.

- Distinguished Singleton Theorem: exhaustive check over all size-5 and size-6 subsets of the 24 primitive unoriented directions with `||u||_infty<=4`, for every possible distinguished direction: **1,020,096 distinguished cases, zero exceptions**.
- Exceptional low-two-turn search with link lengths at most 5:
  - `U_{\{1\}}`: 13,094 distinct free traces generated, 12,052 admissible; no growing confined-cost pattern at free budget <=2;
  - `U_{\{1,2\}}`: 40,596 distinct free traces generated, 36,961 admissible; no growing confined-cost pattern at free budget <=2.
- Canonical triangular-strip values agree exactly with the repaired automaton formula for all tested sizes.

---

## 7. Audit status

### Freeze now
- global `tau_H(U)` classification;
- bounded-to-linear `Gamma` transition;
- all explicit single-rung extremal families;
- Singleton Determinant Theorem;
- Nonhorizontal Singleton -> `(2,1)`;
- divisible balanced-horizontal branch;
- Distinguished Singleton Theorem;
- `|U|>=5 -> (2,1)`;
- canonical triangular-strip exact theorem (with the automaton proof, not the old conflict-triangle proof).

### Do not freeze yet
- `eta(U_{\{1\}})=2/3`;
- the unconditional global statement `eta(U) in {2/3,1}`;
- the unconditional five-pair global `(tau,eta)` classification.

### Single next mathematical target

\[
\boxed{
\text{Four-Link Unit-Triangular Reduction Lemma}
}
\]

Prove the universal `2/3` upper bound for `U_{\{1\}}` at free budget 3. No other structural gap remains in the current program.
