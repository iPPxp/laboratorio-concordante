# Definitions and Notation

## Host and direction alphabet

\[
H=\{(x,y)\in\mathbb Z^2:y\ge0\}.
\]

`U` is a finite set of primitive unoriented lattice directions. A direction class is represented by a primitive vector, with `u` and `-u` identified.

A `U`-path is a vertex-simple lattice path whose primitive increments have direction class in `U`. A **link** is a maximal consecutive run with the same unoriented direction. For a path `P`,

\[
K(P)=L(P)-1
\]

is its number of turns.

Long compressed links are only notation: before trace validation they are expanded into primitive lattice steps, and every intermediate lattice vertex counts.

## Exact host trace

\[
\operatorname{Tr}_H(P)=V(P)\cap H.
\]

For finite `S subset H`, define

\[
K_H(S;U)=\min\{K(P):P\text{ is a }U\text{-path and }V(P)=S\},
\]

\[
K_{\rm free}(S;U)=\min\{K(P):P\text{ is a }U\text{-path and }\operatorname{Tr}_H(P)=S\}.
\]

The minimum of an empty set is infinity. `S` is **admissible** if both minima are finite.

## Confinement gap

\[
\Delta_H(S;U)=K_H(S;U)-K_{\rm free}(S;U).
\]

When `K_free>0`, one may also use

\[
A_H(S;U)=\frac{K_H(S;U)}{K_{\rm free}(S;U)}.
\]

## Induced confined graph

`G_U(S)` has vertex set `S` and a primitive edge `pq` exactly when the direction class of `q-p` belongs to `U` and `q-p` is one primitive step. A confined exact path is therefore a Hamiltonian path of `G_U(S)`, with turn cost determined by consecutive edge labels.

## Exterior-turn threshold

\[
\tau_H(U)=\min\left\{k\ge0:\sup_{\substack{S\text{ admissible}\\K_{\rm free}(S;U)\le k}}K_H(S;U)=\infty\right\}.
\]

If the set is empty, `tau_H(U)=infinity`.

This parameter measures the minimum free turn budget at which the exterior can generate arbitrarily large confined complexity.

## Extremal gap function

\[
\Gamma_U(k,N)=\max\left\{\Delta_H(S;U):S\text{ admissible},\ |S|\le N,\ K_{\rm free}(S;U)\le k\right\}.
\]

The `<=N` convention is deliberate: it removes irrelevant parity gaps among explicit families.

## Asymptotic gap density

\[
\gamma_U(k)=\limsup_{N\to\infty}\frac{\Gamma_U(k,N)}N.
\]

Since every Hamiltonian path on `n` vertices has at most `n-2` turns, `0<=gamma_U(k)<=1`.

## Threshold intensity

\[
\eta(U)=\gamma_U(\tau_H(U))
\]

when `tau_H(U)<infinity`.

`tau` records the onset of amplification; `eta` records its extremal density exactly at onset.

## Pencil alphabets

The residual pencil coordinates of Paper IIII have the form

\[
U_J=\{(1,0),(0,1)\}\cup\{(1,k):k\in J\},
\]

where `J` is a finite subset of positive integers. We write `h=(1,0)`, `v=(0,1)`, and `d_k=(1,k)`.

## Determinant multiplicity

For `r in U` and positive integer `delta`,

\[
m_r(\delta)=\#\{w\in U\setminus\{r\}:|\det(r,w)|=\delta\}.
\]

A class with `m_r(delta)=1` is a **singleton transverse determinant class**.

A triple `{u,v,w}` is **determinant-balanced** when all three nonzero pairwise determinant magnitudes are equal.
