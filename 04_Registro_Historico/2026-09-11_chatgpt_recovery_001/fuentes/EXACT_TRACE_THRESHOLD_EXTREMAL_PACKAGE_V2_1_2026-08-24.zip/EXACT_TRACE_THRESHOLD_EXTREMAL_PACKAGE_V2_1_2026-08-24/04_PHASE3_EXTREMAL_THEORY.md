# Phase 3 — Extremal Theory

## 1. Bounded-to-linear jump

Recall

\[
\Gamma_U(k,N)=\max\{\Delta_H(S;U):S\text{ admissible},\ |S|\le N,\ K_{\rm free}(S;U)\le k\}.
\]

### Below threshold

If `k<tau_H(U)`, then by definition

\[
\sup_{K_{\rm free}\le k}K_H<\infty.
\]

Since `0<=Delta_H<=K_H`,

\[
\boxed{\Gamma_U(k,N)=O_{U,k}(1).}
\]

This half is essentially definitional.

### At or above threshold

The definition of `tau` alone gives only unboundedness, not linear growth. The stronger statement uses the explicit classification families: in every finite-threshold branch there is a parameter `p` with

\[
|S_p|=O_U(p),\qquad K_{\rm free}(S_p)\le\tau_H(U),\qquad K_H(S_p)=\Omega_U(p).
\]

Hence for `k>=tau_H(U)`,

\[
\Gamma_U(k,N)=\Omega_U(N).
\]

The trivial Hamiltonian bound `K_H<=|S|-2<=N-2` gives the reverse `O(N)` bound. Therefore

\[
\boxed{k\ge\tau_H(U)\implies\Gamma_U(k,N)=\Theta_U(N).}
\]

This establishes an immediate bounded-to-linear transition: no logarithmic or fractional-power extremal regime occurs once `tau` is crossed.

## 2. Rectilinear sharpness

The improved ladder from Phase 1 has, for even `t`,

\[
|S_t^*|=2t+3,
\qquad K_{\rm free}=4,
\qquad K_H=|S_t^*|-3,
\]

so

\[
\Delta_H=|S_t^*|-7.
\]

For any positive-gap rectilinear trace, low-turn rigidity gives `K_free>=4`, while `K_H<=n-2`; hence

\[
\Delta_H\le n-6.
\]

Because the family sizes have bounded gaps, for every sufficiently large `N`,

\[
N-10\le\Gamma_{U_\square}(k,N)\le N-6\qquad(k\ge4).
\]

Thus

\[
\boxed{\gamma_{U_\square}(k)=0\ (k\le3),\qquad \gamma_{U_\square}(k)=1\ (k\ge4).}
\]

## 3. Maximal family for `U_{23}`

Let

\[
U_{23}=\{(1,0),(0,1),(1,2),(1,3)\}.
\]

For even `p>=2`, define

\[
C=(0,0),
\]

\[
A_i=(i,3i+1),\quad0\le i\le p,
\]

\[
B_j=(j,3j-2),\quad1\le j\le p.
\]

The free witness

\[
A_p\to A_0\to(0,-2)\to B_p
\]

has two turns and exact trace `S_p={C} union A union B`.

For `m=j-i`,

\[
B_j-A_i=(m,3m-3).
\]

The only primitive cross family is `m=1`, giving a horizontal rung `A_iB_{i+1}`. The cap vertex `C` is adjacent only to `A_0`, because `C B_1` would require direction `(1,1)`, absent from `U_{23}`. The opposite end `A_p` is also a leaf.

Degree propagation forces a unique Hamiltonian path (up to reversal), and every internal vertex turns. Therefore

\[
\boxed{K_H(S_p)=|S_p|-2,\qquad K_{\rm free}(S_p)=2,\qquad\Delta_H(S_p)=|S_p|-4.}
\]

Hence

\[
\boxed{\gamma_{U_{23}}(2)=1.}
\]

The reconstructed solver verifies `K_H=n-2` for `p=2,4,6`.

## 4. General `U_{m,m+1}` maximal family

For `m>=2`, set `K=m+1` and

\[
U_{m,m+1}=\{(1,0),(0,1),(1,m),(1,m+1)\}.
\]

For even `p`, define

\[
A_i=(i,Ki+1),\quad0\le i\le p,
\]

\[
B_j=(j,Kj-K+1),\quad1\le j\le p,
\]

and `C=(0,0)`. The two-turn free witness

\[
A_p\to A_0\to(0,1-K)\to B_p
\]

visits exactly the trace. Since `(1,1)` is absent for `m>=2`, `C` remains a leaf; the only cross family is horizontal `A_iB_{i+1}`. The same forced graph as in `U_{23}` gives

\[
\boxed{K_H=|S|-2,\qquad K_{\rm free}=2.}
\]

Thus `gamma(2)=1` throughout this infinite family.

## 5. Maximal family for `U_{12}` at threshold 3

For even `p`, let

\[
A_i=(i,2i+1),\quad0\le i\le p,
\]

\[
B_j=(j-2,2j-1),\quad1\le j\le p,
\]

and `C=(0,0)`. The free witness

\[
A_p\to A_0\to(0,-1)\to(-2,-1)\to B_p
\]

has directions `d_2,v,h,d_2` and exactly three turns. Its exact host trace is the declared set.

For `k=j-i`,

\[
B_j-A_i=(k-2,2k-2).
\]

Only `k=1` gives a primitive allowed cross edge, namely a horizontal rung. `C` is not adjacent to `B_1`: the difference is the negative-slope direction `(1,-1)`, not the unoriented class `(1,1)`. Thus the same single-rung forced graph gives

\[
\boxed{K_H=|S|-2.}
\]

Since the threshold classification gives `tau(U_{12})=3`, for all sufficiently large members of this family `K_free=3`. Therefore

\[
\boxed{\gamma_{U_{12}}(3)=1.}
\]

## 6. Intensity-one pencil classes

The same single-rung mechanism proves `gamma(tau)=1` in all pencil classes except `J={1}`:

- `J=emptyset`: improved rectilinear ladder;
- `J={1,2}`: the preceding `U_{12}` family;
- `1 notin J`: use rails in direction `d_K`, where `K=max J`, and a vertical cap. Because `d_1` is absent, the cap is a leaf and only a horizontal rung family remains;
- `1 in J`, `K=max J>=3`: the argument can be made exact. Put `g=K-1`, take
  \[
  A_i=(i,i),\qquad 0\le i\le p,
  \]
  \[
  B_j=(j,j-g),\qquad g\le j\le p-2,
  \]
  and choose `p-g` odd. The free path
  \[
  A_p\to A_{-1}\to B_{-1}\to B_{p-2}
  \]
  has two turns and its middle vertical connector is wholly below `H`. For `m=j-i`,
  \[
  B_j-A_i=(m,m-g).
  \]
  The only primitive cross family is `m=-1`, which is the direction `d_K`; `m=0` is a nonprimitive vertical jump, `m=1` has nonpositive slope `2-K`, and `|m|>=2` cannot be a primitive pencil step. Thus `A_0` and `A_p` are the two leaves. The initial chain
  \[
  A_0,A_1,\ldots,A_{g+1}
  \]
  is forced, after which degree propagation forces the repeating pattern
  \[
  B_g,B_{g+1},A_{g+2},A_{g+3},B_{g+2},B_{g+3},A_{g+4},A_{g+5},\ldots,A_p.
  \]
  There are exactly `g` straight internal vertices in the initial `A`-prefix and every subsequent internal vertex turns. Since
  \[
  |S|=(p+1)+(p-g-1)=2p-g,
  \]
  we obtain the exact formula
  \[
  K_H(S)=|S|-g-2=|S|-K-1.
  \]
  Hence, for fixed `U`, `K_H/|S| -> 1`.

Therefore

\[
\boxed{J\ne\{1\}\implies\gamma_{U_J}(\tau_H(U_J))=1.}
\]

## 7. Unit triangular closure and global intensity

Phase 5 replaced the incomplete strip proof by a four-state cut automaton and Phase VI proved the missing four-link reduction at threshold three. Consequently

\[
\boxed{\gamma_{U_{\{1\}}}(3)=2/3.}
\]

Together with the single-rung and balanced-triangular classifications, every finite-threshold alphabet satisfies

\[
\boxed{\eta(U)=\gamma_U(\tau_H(U))\in\{1,2/3\}.}
\]

The finite pair set is

\[
\boxed{(4,1),(3,1),(3,2/3),(2,1),(2,2/3).}
\]
