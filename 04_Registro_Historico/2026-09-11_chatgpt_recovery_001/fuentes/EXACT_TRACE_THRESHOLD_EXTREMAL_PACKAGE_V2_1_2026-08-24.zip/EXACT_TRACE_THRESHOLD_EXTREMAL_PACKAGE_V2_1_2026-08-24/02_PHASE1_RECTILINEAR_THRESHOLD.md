# Phase 1 — Sharp Rectilinear Exterior-Turn Threshold

Let

\[
U_\square=\{(1,0),(0,1)\}.
\]

The Phase-1 result is

\[
\boxed{\tau_H(U_\square)=4}.
\]

It rests on a low-turn clipping theorem and an explicit four-turn amplifying ladder.

## 1. Four-link normal form

Let `P` be a vertex-simple rectilinear free path with at most three turns. Remove any wholly exterior prefix or suffix; this does not alter its host trace or increase turns.

If the host vertices occur consecutively in the order of `P`, the subpath between the first and last host vertex is already confined, with no larger turn count.

Otherwise the path must leave `H` and later return. Rectilinearity forces two vertical crossings of `y=0` separated by a horizontal exterior link. Thus, up to reversal, the relevant form is either

\[
V-H_{\rm out}-V
\]

or

\[
H-V-H_{\rm out}-V.
\]

There is no other orientation pattern with at most four links that can exit and re-enter the half-plane.

## 2. Two-column clipping

A three-link split trace has the form

\[
(a,A)\to(a,-d)\to(b,-d)\to(b,B),
\qquad A,B\ge0,\ d\ge1.
\]

Its host trace is the union of two vertical columns `C_a,C_b`. Admissibility implies that the induced grid graph is connected, so the columns must be horizontally adjacent:

\[
|a-b|=1.
\]

Hence the confined path

\[
(a,A)\downarrow(a,0)\to(b,0)\uparrow(b,B)
\]

uses at most two turns.

## 3. Adjacency classification for an L plus one column

In the four-link case write, after reflection if necessary,

\[
(c,A)\to(a,A)\to(a,-d)\to(b,-d)\to(b,B),\qquad a<c.
\]

The trace is

\[
S=R\cup C_a\cup C_b,
\]

where

\[
R=\{(x,A):a\le x\le c\},
\]

and `C_a,C_b` are vertical columns. Vertex-simplicity implies `C_b cap R` is empty.

If `G(S)` is connected, exactly one of the following occurs:

1. `|a-b|=1` (adjacent columns);
2. `a<b<=c` and `B=A-1` (vertical contact from below the arm);
3. `b=c+1` and `B>=A` (horizontal contact beyond the far endpoint).

This is exhaustive because, after excluding direct column-column adjacency, every connection from `C_b` to `R` is either vertical or horizontal in the square grid.

## 4. Three-turn clipping

- In case 1, move the exterior horizontal link to `y=0`; the resulting path is confined with at most three turns.
- In case 2, if `a<b<c`, the induced graph has three leaves `(a,0),(b,0),(c,A)`, impossible for a graph with a Hamiltonian path. Thus `b=c`, and a two-turn confined traversal exists.
- In case 3, if `A>0` and `B>A`, the induced graph again has three leaves `(a,0),(b,0),(b,B)`. Hence `B=A`; the remaining trace has a two-turn confined traversal. `A=0` is a simpler degeneration.

Therefore every admissible split trace produced by at most four rectilinear links has a confined realization with no larger turn count.

## Theorem — rectilinear low-turn rigidity

For every admissible `S subset H`,

\[
\boxed{K_{\rm free}(S;U_\square)\le3\implies K_H(S;U_\square)=K_{\rm free}(S;U_\square).}
\]

The inequality `K_free<=K_H` is automatic; the preceding normal-form and clipping lemmas give the reverse inequality.

A reconstructed finite scan (`data/rectilinear_low_turn_scan.json`) enumerates 5,072 normalized traces from simple rectilinear witnesses with at most four links and run length at most 3. Of 4,908 admissible traces, the maximum exact `K_H` in free-witness classes `k=0,1,2,3` is respectively `0,1,2,3`. This is a regression control, not part of the proof.

## 5. Sharp four-turn ladder

For odd `t>=3`, define

\[
S_t=\{(i,1),(i,2):0\le i\le t\}\cup\{(0,0),(t,0)\}.
\]

There are `2t+4` vertices. The two lower vertices are the unique leaves, so every Hamiltonian path must use them as endpoints. Degree-two propagation forces, up to reversal,

\[
(0,0),(0,1),(0,2),(1,2),(1,1),(2,1),(2,2),\ldots,(t,2),(t,1),(t,0).
\]

For odd `t` the propagation reaches the correct endpoint. Only the two vertices on the terminal vertical columns are straight-through, giving

\[
\boxed{K_H(S_t)=2t=|S_t|-4.}
\]

A free witness is

\[
(0,2)\to(t,2)\to(t,-1)\to(0,-1)\to(0,1)\to(t-1,1).
\]

After primitive expansion, its exact host trace is `S_t`, it is vertex-simple, and it uses four turns. Thus `K_free<=4`. Low-turn rigidity rules out `K_free<=3`, so

\[
\boxed{K_{\rm free}(S_t)=4.}
\]

Hence `tau_H(U_square)=4`.

## 6. Improved rectilinear extremal ladder

For even `t>=2`, remove the upper-left vertex from the preceding type of ladder:

\[
S_t^*=\{(i,1):0\le i\le t\}\cup\{(i,2):1\le i\le t\}\cup\{(0,0),(t,0)\}.
\]

Then `|S_t^*|=2t+3`. The free witness

\[
(t-1,1)\to(0,1)\to(0,-1)\to(t,-1)\to(t,2)\to(1,2)
\]

has exact trace `S_t^*` and four turns. Degree propagation yields a unique Hamiltonian path (up to reversal) in which exactly one internal vertex is straight, so

\[
\boxed{K_H(S_t^*)=2t=|S_t^*|-3,\qquad K_{\rm free}(S_t^*)=4.}
\]

Thus

\[
\Delta_H(S_t^*)=|S_t^*|-7.
\]

The reconstructed exact solver verifies these formulas for `t=2,4,6`.
