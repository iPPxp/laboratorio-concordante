# Open Problems — Post–Phase VI

The threshold/intensity classification itself is no longer listed as open. The following are the genuine remaining problems in this static exact-trace program.

## Priority 1 — Algorithmic complexity

Determine the computational complexity of evaluating

\[
K_H(S;U),\qquad K_{\rm free}(S;U)
\]

for fixed finite `U`.

Natural targets:

- NP-hardness versus fixed-parameter tractability by turn budget;
- certificate size and normal forms for `K_free`;
- complexity dichotomy by alphabet;
- bounded-width host or trace parameters.

## Priority 2 — Exact finite-`N` extremal functions

The asymptotic onset and intensity are classified, but exact or second-order forms of

\[
\Gamma_U(\tau_H(U),N)
\]

remain largely open outside the sharp model families. Determine additive constants, parity effects, and whether every class admits eventually periodic exact extremal functions.

## Priority 3 — Host classification

Replace the half-plane by other fixed hosts: strips, quadrants, rational wedges, rational convex regions, or periodic hosts. Determine which parts of `tau` and `eta` are host invariants and which depend on boundary arithmetic.

## Priority 4 — Noncrossing / geometric simplicity

The present model is vertex-simple but permits nonlattice geometric crossings. Reclassify `tau` and `eta` under a noncrossing requirement.

## Priority 5 — Continuous-bend exact-site analogue

Allow bends at arbitrary Euclidean points while still fixing the exact visited host lattice sites. Separate rational and irrational orientation phenomena.

## Priority 6 — Higher-dimensional analogues

Define an appropriate turn/link-change cost for primitive lattice paths in `Z^d`, choose fixed hosts such as half-spaces, and ask for onset and intensity classifications.

## Priority 7 — Structural uniqueness of extremizers

Classify, up to bounded perturbation, all threshold-extremal families with intensity `1` and `2/3`. The current proofs identify single-rung and triangular-strip mechanisms, but a uniqueness/stability theorem would be stronger.

## Priority 8 — Dedicated novelty audit

Perform a literature search specifically for:

- determinant-multiplicity singleton theorems in rank two;
- minimum-turn Hamiltonian paths in triangular ladder/strip graphs with direction-labeled turns;
- threshold resource invariants analogous to `tau` in covering/spanning path literature.

No priority claim should be made before that audit.
