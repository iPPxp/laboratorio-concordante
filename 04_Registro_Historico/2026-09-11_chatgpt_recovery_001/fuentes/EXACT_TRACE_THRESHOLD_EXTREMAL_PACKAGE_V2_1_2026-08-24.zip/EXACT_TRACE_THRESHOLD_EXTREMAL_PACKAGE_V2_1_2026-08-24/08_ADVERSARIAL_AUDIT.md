# Adversarial Audit and Repaired Claims — Full Trail

This file preserves errors and corrections instead of erasing them.

## A1. Unvisited-cap bug — SUPERSEDED

An early top-gap family declared cap vertices not visited by its free witness. Exact trace therefore failed. Repair: move the free connector so it traverses the cap primitive-step by primitive-step before exiting the host. The repaired top-gap theorem survives.

## A2. Partially visible middle-link omission — REPAIRED

Early `U_1` and `U_{1,2}` lower-threshold arguments assumed the middle link of every three-link free witness was wholly outside `H`. It may have a visible prefix. Repair: support-line reduction plus determinant bounds on connector length and a boundary-entry bridge/splice. The arbitrary numeric bounds `12` and `16` were withdrawn; only uniform `O_U(1)` boundedness is retained.

## A3. Pencil sublattice/coset transfer — REPAIRED

Coordinate pencils can live in a proper sublattice. A lower-bound theorem must control every coset. Repair: every allowed path remains in one coset `c+L`; after choosing the canonical representative, the map `Psi_c(i,j)=c+ih+jv` preserves the half-plane predicate, primitive steps, vertex simplicity, exact trace, and turns.

## A4. `eta(U_1)=2/3` promoted too early — DOWNGRADED THEN RE-PROVED

Phase 3.3/4.4 promoted the value `2/3` before proving a universal upper bound for every trace with `K_free<=3`. Phase 5 correctly downgraded it because budget three permits **four links**, while the available reduction covered only three links. Phase VI supplies the missing Four-Link Unit-Triangular Reduction Theorem. Final status: `PROVED_AFTER_REPAIR`.

## A5. Incomplete straight-conflict proof for triangular strip — SUPERSEDED

The first exact-strip proof used local “conflict triangles” of straight vertices. The claimed local exclusion did not justify every pair. Phase 5 replaced it with a four-state cut automaton. The terminal-constrained theorem survives:

\[
K_H^{\rm term}(T_n)=\left\lfloor\frac{2|V(T_n)|}{3}\right\rfloor.
\]

Only the automaton proof should be used. The bare strip with free endpoints is a different optimization problem.

## A6. Overbroad singleton-to-intensity implication — SUPERSEDED

The phrase “singleton determinant class implies eta=1” ignored host orientation. A singleton whose unique representative is horizontal need not directly yield the generic single-rung construction. Repair:

1. prove the **nonhorizontal singleton bridge**;
2. classify the residual `horizontal + balanced triple` family by a height-divisibility dichotomy;
3. prove the Distinguished Singleton Theorem for `|U|>=5` so a useful singleton can always be chosen away from the horizontal.

## A7. Balanced-triple host transfer — REPAIRED

The algebraic statement `w=u+v` does not by itself permit arbitrary affine replacement of the physical host. The final argument separates:

- balanced triples containing the horizontal, handled by faithful pencil/coset coordinates;
- generic balanced triples, handled by the three-link determinant reduction without asserting a host-preserving arbitrary basis change;
- four-direction horizontal+balanced residuals, handled directly in physical height arithmetic.

## A8. Global `(tau,eta)` classification frozen prematurely — REPAIRED

Before Phase 5 the five-pair classification was stated before the four-link `U_1` case was closed. The global RAG explicitly revoked that freeze. Phase VI then proved the missing bounded-port four-link reduction. The global classification is frozen only **after** this repair.

## A9. Bare-strip versus terminal-constrained strip — REPAIRED DURING PACKAGE V2

A post-Phase-VI regression check showed that the formula `floor(2|V|/3)` is not the unrestricted minimum over all Hamiltonian endpoints of the bare triangular strip (already `n=1` has a cheaper free-endpoint traversal). The Phase-5 automaton had fixed admissible initial/terminal states inherited from the extremal gadget/ports. Repair at v2: state the exact theorem as a **terminal-constrained** strip theorem.  The extreme post-v2 audit then showed that the proposed parity-only bounded-port extension still lacked connectivity state; that second issue is repaired separately in A10 by the 12-state connectivity automaton.  The lower-bound gadget continues to use the terminal-constrained exact theorem.


## A10. Extreme-RAG connectivity objection — REPAIRED IN v2.1

The post-v2 extreme audit correctly observed that the four-state cut automaton did not encode connectivity/pairing and therefore could not justify arbitrary bounded-port replacement.  v2.1 does **not** patch that argument verbally.  It replaces it with a 12-state connectivity frontier automaton.  States encode crossing stubs, their pairing through the processed prefix, and attachment to global endpoint labels.  The exact transfer graph has 17 transitions and forbids prematurely closed components.

The finite max-plus certificate proves `supp(A^6) subset supp(A^3)` and `A^6 >= A^3+2`, yielding `F_n >= 2n/3-7/3` for every feasible connectivity state pair.  Replacement with identical initial and terminal connectivity states therefore preserves the global Hamiltonian path.

The same certificate supplies the previously unwritten end-splice control in the three-link triangular reductions.

## A11. Exceptional-pencil finite bridge debt — REPAIRED IN v2.1

The extreme audit also required the Phase-2 phrase “finite local case split” to be written explicitly.  The full `U_1/U_{12}` boundary-entry table is now in Phase 2 and `data/exceptional_bridge_table.csv`.  Every determinant-permitted case has a primitive entry shortcut; `U_1` has `ell=1`, while `U_{12}` has `ell<=2` and at most one visible connector interior vertex.

## Claims surviving the complete audit

- Paper IIII qualitative classification and two-rail lemma;
- universal one-turn obstruction;
- rectilinear low-turn rigidity and `tau=4`;
- exceptional thresholds `tau(U_1)=tau(U_{1,2})=3`;
- repaired pencil `tau` classification and coset normalization;
- bounded-to-linear `Gamma` transition;
- all explicit single-rung extremal families;
- terminal-constrained triangular-strip theorem via four-state automaton;
- Singleton Determinant Theorem;
- Nonhorizontal Singleton Bridge;
- height-divisibility classification for horizontal+balanced triples;
- Distinguished Singleton Theorem and paired-star parity collapse;
- Four-Link Unit-Triangular Reduction Theorem;
- global finite `(tau,eta)` classification.

## Current audit rule

No computation-only result is used as a universal proof. The package's “frozen” classification remains subject to independent specialist review and literature-priority checking.
