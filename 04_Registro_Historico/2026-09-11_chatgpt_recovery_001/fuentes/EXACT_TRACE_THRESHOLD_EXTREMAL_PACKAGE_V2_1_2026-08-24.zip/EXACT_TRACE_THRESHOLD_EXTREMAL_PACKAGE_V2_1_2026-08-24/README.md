# Exact-Trace Threshold and Extremal Research — Formal Consolidation v2.1

This package is the post–extreme-RAG repair of the exact-trace threshold/extremal program developed after Paper IIII.

## Scope

Static discrete/lattice geometry only: exact host traces, Hamiltonian turn cost, finite primitive direction alphabets, threshold/extremal invariants, determinant multiplicities, triangular strips, proof audits, and reproducibility certificates.

## Frozen internal results

\[
\boxed{\tau_H(U)\in\{\infty,4,3,2\}},
\qquad
\boxed{\eta(U)\in\{1,2/3\}}.
\]
Finite `(tau,eta)` pairs:
\[
\boxed{(4,1),(3,1),(3,2/3),(2,1),(2,2/3).}
\]

## What v2.1 repairs

The extreme post-v2 audit found no counterexample but identified two proof-completeness gaps:

1. the `U_1/U_{12}` low-two-turn proof referred to an unwritten finite boundary-entry case split;
2. the Phase-VI strip replacement tracked cut parity but not connectivity/pairing.

v2.1 supplies:

- `code/reconstructed/exceptional_bridge_certificate.py` and `data/exceptional_bridge_table.csv`;
- `code/reconstructed/connectivity_strip_certificate.py`, `data/connectivity_strip_states.csv`, `data/connectivity_strip_transitions.csv`, and `data/connectivity_strip_certificate.json`.

The connectivity certificate is a finite-state proof: 12 states, 17 transitions, and the max-plus identities
\[
\operatorname{supp}(A^6)\subseteq\operatorname{supp}(A^3),\qquad A^6\ge A^3+2.
\]
It explicitly preserves crossing pairing/global-endpoint connectivity and therefore repairs arbitrary slab replacement rather than merely matching cut parity.

## Main documents

- `00_EXECUTIVE_MATH_SUMMARY.md`
- `01_DEFINITIONS_AND_NOTATION.md`
- `02_PHASE1_RECTILINEAR_THRESHOLD.md`
- `03_PHASE2_THRESHOLD_CLASSIFICATION.md`
- `04_PHASE3_EXTREMAL_THEORY.md`
- `05_PENCIL_EXTREMAL_CLASSIFICATION.md`
- `06_DETERMINANT_BALANCED_AND_SINGLETON_CLASSES.md`
- `07_OPEN_PROBLEMS.md`
- `08_ADVERSARIAL_AUDIT.md`
- `09_COMPUTATIONAL_RECONNAISSANCE.md`
- `10_LITERATURE_POSITION.md`
- `11_PHASE4_SINGLETON_AND_BALANCED_CLASSIFICATION.md`
- `12_PHASE5_GLOBAL_RAG_CLOSURE.md` (historical RAG state)
- `13_PHASE6_FOUR_LINK_UNIT_TRIANGULAR_CLOSURE.md`
- `14_V2_1_REFEREE_REPAIR.md`
- `CLAIMS_MATRIX.csv`
- `THEOREM_DEPENDENCY_GRAPH.md`
- `OPEN_PROBLEM_PRIORITY.csv`
- `SOURCE_PROVENANCE.md`
- `VERSION.md`

## Verification

Fast certificate/regression suite:

```bash
bash RUN_QUICK_CHECKS.sh
```

Full historical suite:

```bash
bash RUN_ALL_CHECKS.sh
```

Computation-only scans remain regression evidence.  The two new finite automata/tables are proof certificates for finite case exhaustion and are accompanied by the human derivations in the markdown documents.

## Editorial state

**CLEAR PAPER-SCALE RESULT**, subject to independent specialist referee and dedicated novelty review.
