# Package Version

**Version:** 2.1 — Extreme-RAG referee repair  
**Date:** 2026-08-24  
**Scope:** static exact-host-vertex-trace lattice path theory only.

v2.1 supersedes v2.0 for claim-status purposes while preserving the complete historical audit trail.

### New referee-completeness repairs

1. explicit exceptional-pencil boundary-entry bridge table for `U_1` and `U_{12}`;
2. 12-state connectivity-aware triangular-strip transfer automaton replacing the v2 parity-only bounded-port argument;
3. max-plus finite certificate `supp(A^6) subset supp(A^3)` and `A^6 >= A^3+2`;
4. correction of all remaining unrestricted-strip wording to terminal-constrained or connectivity-aware form as appropriate.

The global classifications are re-frozen internally as `PROVED_AFTER_REPAIR`.  “Frozen” does not mean independently refereed, literature-priority certified, or accepted for publication.
