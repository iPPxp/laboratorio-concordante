# Literature Positioning — Targeted, Conservative Review

This is a targeted positioning review, not a claim of exhaustive priority.

## 1. Hamiltonian grid graphs

**Itai, Papadimitriou, Szwarcfiter (1982), “Hamilton Paths in Grid Graphs,” SIAM Journal on Computing 11(4), 676–686, DOI 10.1137/0211056.**

What it covers: necessary/sufficient conditions for specified-endpoint Hamilton paths in rectangular grid graphs; NP-completeness for Hamilton path/circuit in general node-induced grid graphs.

What it does not cover: turn minimization under a same-`S`, same-`U` free-versus-confined exact-host-trace comparison. It is primarily a feasibility/complexity neighbor.

## 2. Turn-cost covering tours and milling

**Arkin, Bender, Demaine, Fekete, Mitchell, Sethia (2005), “Optimal Covering Tours with Turn Costs,” SIAM Journal on Computing 35(3), 531–566, DOI 10.1137/S0097539703434267.**

What it covers: geometric covering tours with turn-dependent objective; NP-completeness of minimum-turn milling and approximation algorithms/PTAS-type results.

What it does not cover: exact equality of the host-lattice vertex trace between an interior path and an exterior-detour path.

**Fekete, Krupke (2024), “What Goes Around Comes Around: Covering Tours and Cycle Covers with Turn Costs,” Theory of Computing Systems 68, 1207–1238, DOI 10.1007/s00224-024-10178-8.**

What it covers: modern complexity and approximation results for full/subset/penalty cycle covers with turn costs; NP-hardness even in two-dimensional grid settings.

What it does not cover: the exact-trace confinement threshold `tau` or extremal gap density.

## 3. Abstract milling / parameterized turn cost

**Fellows, Giannopoulos, Knauer, Paul, Rosamond, Whitesides, Yu, “Abstract Milling with Turn Costs,” arXiv:0912.1050.**

What it covers: graph-theoretic vertex-covering walks with local 0/1 turn costs; FPT in turns + treewidth + maximum degree and W[1]-hardness for weaker parameter combinations.

What it does not cover: the fixed half-plane, primitive-lattice exact trace, or free exterior routing.

## 4. Rectilinear spanning/covering paths and minimum bends

**Estivill-Castro, Heednacram, Suraweera (2010), “NP-completeness and FPT Results for Rectilinear Covering Problems,” Journal of Universal Computer Science 16(5), 622–652, DOI 10.3217/jucs-016-05-0622.**

What it covers: rectilinear line cover, rectilinear `k`-link spanning paths, NP-completeness, and FPT results; the framework also discusses extension to finite orientation sets.

What it does not cover: the exact primitive host trace, a forbidden half-plane used as a Steiner resource, or the threshold between bounded and unbounded confinement gaps.

**Estivill-Castro, Heednacram, Suraweera (2011), “FPT-Algorithms for Minimum-Bends Tours,” International Journal of Computational Geometry & Applications 21(2), 189–213, DOI 10.1142/S0218195911003615.**

What it covers: parameterized minimum-bend tours through finite point sets.

What it does not cover: same-trace free/confined comparison.

**Wang, Tan, Yao, Feng, Chen (2014), “On the Minimum Link-Length Rectilinear Spanning Path Problem: Complexity and Algorithms,” IEEE Transactions on Computers 63(12), 3092–3100, DOI 10.1109/TC.2013.163.**

What it covers: complexity and algorithms for rectilinear spanning paths through prescribed point sets.

What it does not cover: the exact trace of all primitive intermediate lattice vertices or an exterior-detour confinement gap.

## 5. Minimum-link `C`-oriented routing

**Mitchell, Polishchuk, Sysikaski (2014), “Minimum-Link Paths Revisited,” Computational Geometry; arXiv:1302.3091.**

What it covers: exact and approximation algorithms for minimum-link `C`-oriented paths in geometric domains, plus hardness for unrestricted orientations.

What it does not cover: Hamiltonian traversal of a prescribed lattice trace or exact host-trace equality between two routing regions.

**Kostitsyna, Löffler, Polishchuk, Staals (2017), “On the complexity of minimum-link path problems,” Journal of Computational Geometry; arXiv:1603.06972.**

What it covers: minimum-link paths with restrictions on where edges or bends may occur, hardness, bit complexity, and approximation.

What it does not cover: the present threshold invariant or same-`S`, same-`U` confinement comparison.

## 6. Grid covering and crossing conventions

**Keszegh (2014), “Covering Paths and Trees for Planar Grids,” Geombinatorics; arXiv:1311.0452.**

What it covers: sharp minimum segment counts for covering rectangular point grids, and a concrete distinction between crossing and noncrossing variants.

What it does not cover: induced primitive Hamiltonian graphs or equality of complete host trace in a free/confined pair.

**Speckmann, Verbeek (2018), “Homotopic C-oriented routing with few links and thick edges,” Computational Geometry 67, 11–28, DOI 10.1016/j.comgeo.2017.10.005.**

What it covers: NP-hard noncrossing homotopic `C`-oriented routing, approximation algorithms, and lower bounds on the extra link cost of uncrossing.

What it does not cover: lattice exact traces. It is especially relevant to Paper IIII's open crossing-convention variant.

## 7. Rank-2 determinant structure

**Heller (1957), “On Linear Systems with Integral Valued Solutions,” Pacific Journal of Mathematics 7, 1351–1364.**

A classical consequence used in later literature is the bound `binom(r+1,2)` on the number of nonzero pairwise nonparallel columns of a rank-`r` unimodular matrix.

**Oxley, Walsh (2022), “2-Modular Matrices,” SIAM Journal on Discrete Mathematics 36(2), 1231–1248, DOI 10.1137/21M1419131.**

What it covers: extremal size of pairwise nonparallel column sets under global determinant bound 2, generalizing the unimodular setting.

What it does not cover: the **multiplicity pattern** of determinant magnitudes relative to each fixed direction. The singleton problem in this package asks a different rank-2 question: whether a sufficiently large primitive direction set must contain some row of pairwise minors with a value occurring exactly once.

## 8. Novelty boundary

The literature above shows that none of the following, by itself, should be marketed as new: Hamiltonian grid paths, turn minimization, finite-orientation minimum-link routing, Steiner/covering bends, or large complexity changes caused by geometric restrictions.

The potential new contribution is narrower:

1. the exact-host-vertex-trace same-`S`, same-`U` free/confined model inherited from Paper IIII;
2. the new minimum exterior-turn resource `tau_H(U)` and its exact alphabet classification;
3. the budgeted extremal gap functions `Gamma` and `gamma`, together with sharp families reaching `|S|-O(1)` confined complexity at threshold.

A targeted web search did not identify a paper directly subsuming this threshold/extremal exact-trace classification. That is **not** a definitive priority claim; specialist review remains appropriate.

## 9. Post–Phase VI literature caution

The mathematical package now contains two theorem families that were not the focus of the earlier targeted review: (i) singleton multiplicity theorems for absolute `2x2` determinants of primitive rank-2 direction sets, and (ii) an exact minimum-turn Hamiltonian formula for a direction-labeled triangular strip, together with bounded-port extensions. The previous literature review should **not** be treated as establishing novelty for these Phase-4/VI results. A fresh specialist search is required before making priority claims.
