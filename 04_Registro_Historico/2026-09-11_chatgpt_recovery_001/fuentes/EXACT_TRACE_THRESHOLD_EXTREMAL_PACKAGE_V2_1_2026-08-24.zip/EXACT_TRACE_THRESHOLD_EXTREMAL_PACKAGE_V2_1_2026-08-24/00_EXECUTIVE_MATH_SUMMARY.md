# Executive Mathematical Summary — v2.1 Referee-Complete Repair

## 1. Baseline

Paper IIII compares confined and free exact host traces for primitive-step lattice paths in
\[
H=\{(x,y)\in\mathbb Z^2:y\ge0\}.
\]
It proves unbounded confinement amplification iff the finite direction alphabet contains at least two nonparallel orientations.

## 2. Onset threshold

Define
\[
\tau_H(U)=\min\left\{k:\sup_{K_{\rm free}(S;U)\le k}K_H(S;U)=\infty\right\}.
\]
The repaired classification is
\[
\boxed{\tau_H(U)\in\{\infty,4,3,2\}}.
\]
For pencil alphabets
\[
U_J=\{(1,0),(0,1)\}\cup\{(1,k):k\in J\},
\]
\[
\boxed{\tau_H(U_J)=4\ (J=\varnothing),\quad 3\ (J=\{1\},\{1,2\}),\quad 2\ \text{otherwise}.}
\]
The v2.1 repair makes the exceptional lower-threshold step referee-complete by replacing the phrase “finite local case split” with an explicit boundary-entry bridge table for every determinant-permitted `U_1` and `U_{12}` case.

## 3. Bounded-to-linear transition

For
\[
\Gamma_U(k,N)=\max\{\Delta_H(S;U):|S|\le N,\ K_{\rm free}\le k\},
\]
\[
k<\tau\Rightarrow\Gamma_U(k,N)=O_{U,k}(1),\qquad k\ge\tau\Rightarrow\Gamma_U(k,N)=\Theta_U(N).
\]

## 4. Threshold intensity

For finite threshold define
\[
\eta(U)=\limsup_{N\to\infty}\Gamma_U(\tau_H(U),N)/N.
\]
The repaired global classification is
\[
\boxed{\eta(U)\in\{1,2/3\}},
\]
with finite pairs
\[
\boxed{(4,1),(3,1),(3,2/3),(2,1),(2,2/3).}
\]
`eta=1` is the single-rung mechanism; `eta=2/3` is the triangular-strip mechanism.

## 5. Two strip theorems

The **terminal-constrained canonical strip theorem** remains exact:
\[
K_H^{\rm term}(T_n)=\left\lfloor2|V(T_n)|/3\right\rfloor.
\]
The unrestricted bare strip is a different optimization problem.

The new v2.1 theorem is stronger in a different direction: it handles **arbitrary feasible boundary connectivity**.  A cut has three possible crossing edges.  The processed prefix of a Hamiltonian path is a linear forest, so its crossing set, pairings, and attachments to zero, one, or two global endpoints form exactly 12 frontier states.  Exhausting degree-two local transitions yields 17 transitions.

For the 12-by-12 max-plus transfer matrix `A`, the proof certificate verifies
\[
\operatorname{supp}(A^6)\subseteq\operatorname{supp}(A^3),\qquad A^6\ge A^3+2.
\]
With bases `0,...,5`, every feasible state pair satisfies
\[
F_n\ge 2n/3-7/3.
\]
Thus every clean triangular slab can be replaced while preserving its **full connectivity state** with turn cost at most `2/3` of its vertices plus a constant.  This is the repair demanded by the extreme RAG.

## 6. Unit triangular four-link closure

For `U_1`, every four-link threshold witness has at most one unbounded triangular core; all other support interactions occur through `O(1)` junctions.  Cutting around those junctions gives `O(1)` clean slabs.  Replacing each slab with the same initial/terminal connectivity states preserves the global Hamiltonian path and gives
\[
K_H(S;U_1)\le\frac23|S|+O(1).
\]
The matching threshold family gives
\[
\boxed{\eta(U_1)=2/3}.
\]
The same connectivity-aware transfer theorem also removes the previously unwritten end-splice debt in the threshold-two balanced triangular reductions.

## 7. Determinant multiplicity structure

The package proves:

- the only nontrivial no-singleton direction sets are determinant-balanced triples;
- every `|U|>=4` has a singleton determinant class;
- every `|U|>=5` has a singleton avoiding any prescribed direction `e`;
- choosing `e` horizontal gives `|U|>=5 -> (tau,eta)=(2,1)`.

## 8. Audit status

The audit trail preserves all superseded arguments: unvisited cap, partially visible connector, arbitrary sublattice transfer, overbroad singleton implication, incomplete conflict-triangle proof, bare-strip/terminal confusion, and the v2 connectivity omission.

The v2.1 re-freeze is based on two explicit proof certificates:

- `exceptional_bridge_certificate.py` / `exceptional_bridge_table.csv`;
- `connectivity_strip_certificate.py` / the 12-state and 17-transition tables.

## 9. Editorial assessment

\[
\boxed{\text{CLEAR PAPER-SCALE RESULT}}
\]

The internal proof program has no currently known structural gap after the extreme-RAG repair.  Independent specialist review and a dedicated novelty audit remain required before external priority claims.
