#!/usr/bin/env python3
"""RECONSTRUCTED POST-PHASE-VI REGRESSION CONTROL.

Checks the endpoint-constrained Hamiltonian turn cost of the canonical U_1
triangular strip with endpoints B_0 and B_{n+1}. This is the terminal-state
problem used by the strip automaton, not the unrestricted K_H of the bare graph.
Regression only; not a proof.
"""
from __future__ import annotations
from collections import deque
import csv, json, sys
from pathlib import Path

HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]
sys.path.insert(0, str(ROOT/'code'/'original_paper_iiii'/'src'))
from exact_trace_confinement import induced_primitive_graph  # type: ignore

U=[(1,0),(0,1),(1,1)]

def strip(n:int):
    return {(0,i) for i in range(n+1)} | {(1,j) for j in range(n+2)}

def exact_fixed_endpoints(S, start, target):
    g0=induced_primitive_graph(S,U); verts=sorted(g0); idx={p:i for i,p in enumerate(verts)}
    g=[[(idx[q],lab) for q,lab in g0[p].items()] for p in verts]
    s=idx[start]; t=idx[target]; full=(1<<len(verts))-1
    dist={}; dq=deque()
    for nxt,lab in g[s]:
        st=((1<<s)|(1<<nxt),nxt,lab); dist[st]=0; dq.append((st,0))
    best=None
    while dq:
        st,val=dq.popleft()
        if val!=dist.get(st): continue
        mask,end,last=st
        if mask==full and end==t:
            best=val; break
        for nxt,lab in g[end]:
            if mask>>nxt & 1: continue
            nv=val+(lab!=last); ns=(mask|(1<<nxt),nxt,lab)
            if nv>=dist.get(ns,10**9): continue
            dist[ns]=nv
            (dq.append if lab!=last else dq.appendleft)((ns,nv))
    return best, len(dist)

def main():
    rows=[]
    for n in range(1,9):
        S=strip(n); start=(1,0); target=(1,n+1)
        cost,states=exact_fixed_endpoints(S,start,target)
        expected=(2*len(S))//3
        if cost != expected:
            raise AssertionError((n,len(S),cost,expected))
        rows.append({'n':n,'n_vertices':len(S),'fixed_endpoints':'B0,B(n+1)','exact_turns':cost,'expected_floor_2n_over_3':expected,'dp_states':states})
    (ROOT/'data'/'triangular_strip_regression.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    with (ROOT/'data'/'triangular_strip_regression.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print('TRIANGULAR_STRIP_TERMINAL_REGRESSION_PASS')

if __name__=='__main__': main()
