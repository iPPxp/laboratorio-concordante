#!/usr/bin/env python3
"""RECONSTRUCTED FROM CHAT DESCRIPTION.

Standardized finite scan for the rectilinear low-turn clipping claim.
Enumerates simple compressed rectilinear paths with 1--4 links, run length <= D,
starting x=0 and y in [-D,D], normalizes traces by horizontal translation, and
computes exact confined turn cost by the preserved Paper IIII solver.

This is a regression test, not a proof. Its enumeration convention is documented
here and should not be conflated with differently normalized counts reported during
interactive exploration.
"""
from __future__ import annotations

import csv
import json
import sys
from itertools import product
from math import inf
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code" / "original_paper_iiii" / "src"))
from exact_trace_confinement import exact_min_internal_turns  # type: ignore


def enumerate_traces(D=3):
    traces = {}
    for L in range(1, 5):
        for first in (0, 1):  # 0=horizontal, 1=vertical
            dirs = [(1, 0) if (first + i) % 2 == 0 else (0, 1) for i in range(L)]
            for signs in product((-1, 1), repeat=L):
                for lengths in product(range(1, D + 1), repeat=L):
                    for y0 in range(-D, D + 1):
                        x, y = 0, y0
                        walk = [(x, y)]
                        seen = {(x, y)}
                        simple = True
                        for (dx, dy), sign, length in zip(dirs, signs, lengths):
                            for _ in range(length):
                                x += sign * dx
                                y += sign * dy
                                if (x, y) in seen:
                                    simple = False
                                    break
                                seen.add((x, y)); walk.append((x, y))
                            if not simple:
                                break
                        if not simple:
                            continue
                        S = {(xx, yy) for xx, yy in walk if yy >= 0}
                        if not S:
                            continue
                        min_x = min(xx for xx, _ in S)
                        normalized = frozenset((xx - min_x, yy) for xx, yy in S)
                        k = L - 1
                        traces[normalized] = min(traces.get(normalized, 99), k)
    return traces


def main():
    D = 3
    traces = enumerate_traces(D)
    counts = {k: 0 for k in range(4)}
    max_kh = {k: -1 for k in range(4)}
    admissible = 0
    violations = []
    for S, k in traces.items():
        sol = exact_min_internal_turns(S, [(1, 0), (0, 1)])
        if sol.cost == inf:
            continue
        admissible += 1
        kh = int(sol.cost)
        counts[k] += 1
        max_kh[k] = max(max_kh[k], kh)
        if kh > k:
            violations.append({"k": k, "KH": kh, "trace": sorted(S)})
    result = {
        "D": D,
        "distinct_normalized_traces": len(traces),
        "admissible_traces": admissible,
        "admissible_by_min_generated_turns": counts,
        "max_KH_by_min_generated_turns": max_kh,
        "violations_KH_gt_k": violations,
    }
    (ROOT / "data" / "rectilinear_low_turn_scan.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    with (ROOT / "data" / "rectilinear_low_turn_scan_summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["k", "admissible_count", "max_KH"])
        w.writeheader()
        for k in range(4):
            w.writerow({"k": k, "admissible_count": counts[k], "max_KH": max_kh[k]})
    if violations:
        raise AssertionError(f"found {len(violations)} violations")
    print(result)
    print("RECTILINEAR_LOW_TURN_SCAN_PASS")

if __name__ == "__main__":
    main()
