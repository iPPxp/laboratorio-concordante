#!/usr/bin/env python3
"""Finite bridge table for the exceptional low-two-turn pencils U1 and U12.

This is an exact finite certificate for the local boundary-entry shortcut used
in the threshold lower bounds.  It does not enumerate arbitrary long rails;
it enumerates the only connector lengths permitted by determinant ratios and
all possible first-host height residues of a nonhorizontal rail.
"""
from __future__ import annotations
from math import gcd
from pathlib import Path
import csv,json

HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]

def det(a,b):return a[0]*b[1]-a[1]*b[0]
def canon(v):
    x,y=v
    if x==0 and y==0:return None
    g=gcd(abs(x),abs(y)); x//=g;y//=g
    if x<0 or (x==0 and y<0):x=-x;y=-y
    return (x,y)

def rows_for(name,U):
    allowed={canon(u) for u in U}
    rows=[]
    for r in U:
        if r[1]==0:
            rows.append({'alphabet':name,'rail':str(r),'connector':'*','ell':'*','entry_residue':'*',
                         'shortcut':'CLIP','status':'horizontal rails: either one support contributes no long host trace, or the constant connector is visible and clipping is immediate'})
            continue
        maxdet=max(abs(det(r,w)) for w in U if canon(w)!=canon(r))
        for q in U:
            if canon(q)==canon(r):continue
            dq=abs(det(r,q))
            if dq==0:continue
            for ell in range(1,4):
                target=ell*dq
                if target>maxdet:continue
                if not any(abs(det(r,w))==target for w in U if canon(w)!=canon(r)):
                    continue
                for s in range(r[1]):
                    # first host heights on the two ascending r-rails are residues
                    # s and s' in [0,r_y-1].  Separation is ell*q plus k*r.
                    raw=s+ell*q[1]
                    sp=raw % r[1]
                    k=(sp-raw)//r[1]
                    diff=(ell*q[0]+k*r[0], ell*q[1]+k*r[1])
                    cd=canon(diff)
                    ok=(cd in allowed and gcd(abs(diff[0]),abs(diff[1]))==1)
                    rows.append({'alphabet':name,'rail':str(r),'connector':str(q),'ell':ell,'entry_residue':s,
                                 'shortcut':str(diff),'status':'PASS' if ok else 'FAIL'})
                    if not ok:
                        raise AssertionError((name,r,q,ell,s,diff,cd,allowed))
    return rows

def main():
    U1=[(1,0),(0,1),(1,1)]
    U12=[(1,0),(0,1),(1,1),(1,2)]
    rows=rows_for('U1',U1)+rows_for('U12',U12)
    # Exact expected facts: U1 nonhorizontal cases ell=1 only; U12 ell<=2.
    for row in rows:
        if row['ell']=='*':continue
        if row['alphabet']=='U1' and row['ell']!=1:raise AssertionError(row)
        if row['alphabet']=='U12' and int(row['ell'])>2:raise AssertionError(row)
    with (ROOT/'data'/'exceptional_bridge_table.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
    summary={
      'rows':len(rows),
      'statement_U1':'Every nonhorizontal direct-rail case has connector length ell=1 and the two first-host rail entries are joined by one permitted primitive edge.',
      'statement_U12':'Every nonhorizontal direct-rail case has ell<=2.  For d2 rails and ell=2 the entry shortcut is horizontal; every ell=1 residue case also has a permitted primitive shortcut.',
      'visible_middle_fragment':'At most ell-1 connector vertices can be visible.  Thus U1 has none beyond endpoints; U12 has at most one, and it can be inserted as a constant-size local splice.',
      'all_rows_pass':all(r['status']!='FAIL' for r in rows),
    }
    (ROOT/'data'/'exceptional_bridge_certificate.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('EXCEPTIONAL_BRIDGE_CERTIFICATE_PASS')
if __name__=='__main__':main()
