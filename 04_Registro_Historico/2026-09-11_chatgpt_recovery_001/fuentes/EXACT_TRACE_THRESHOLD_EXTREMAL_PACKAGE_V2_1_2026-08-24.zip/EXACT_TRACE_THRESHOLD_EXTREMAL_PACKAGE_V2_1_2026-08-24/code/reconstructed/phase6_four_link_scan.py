#!/usr/bin/env python3
"""RECONSTRUCTED POST-PHASE-VI FINITE FOUR-LINK SCAN.

Enumerates a documented bounded family of exactly four-link U_1 free witnesses,
deduplicates exact host traces up to horizontal translation, and computes exact
confined Hamiltonian turn costs on manageable instances. Regression only.
"""
from __future__ import annotations
from itertools import product
from math import isfinite
import csv, json, sys
from pathlib import Path

HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]
sys.path.insert(0, str(ROOT/'code'/'original_paper_iiii'/'src'))
from exact_trace_confinement import expand_link_endpoints, exact_min_internal_turns, canonical_direction  # type: ignore

U=((1,0),(0,1),(1,1))
SIGNED={
    0:((1,0),(-1,0)),
    1:((0,1),(0,-1)),
    2:((1,1),(-1,-1)),
}

def norm_trace(S):
    if not S: return None
    minx=min(x for x,y in S)
    return tuple(sorted((x-minx,y) for x,y in S))

def main():
    traces={}
    generated=0
    # 4 links, each primitive run length 1..2; starts straddle the host boundary.
    for dirs in product(range(3), repeat=4):
        if any(dirs[i]==dirs[i+1] for i in range(3)): continue
        for signs in product((0,1), repeat=4):
            steps=[SIGNED[d][s] for d,s in zip(dirs,signs)]
            for lengths in product((1,2), repeat=4):
                for y0 in range(-3,4):
                    pts=[(0,y0)]; x,y=pts[0]
                    endpoints=[pts[0]]
                    for (dx,dy),L in zip(steps,lengths):
                        x+=dx*L; y+=dy*L; endpoints.append((x,y))
                    try:
                        expanded=expand_link_endpoints(endpoints)
                    except ValueError:
                        continue
                    if len(expanded)!=len(set(expanded)): continue
                    # exactly the intended unoriented link sequence
                    actual=[canonical_direction(endpoints[i+1][0]-endpoints[i][0], endpoints[i+1][1]-endpoints[i][1]) for i in range(4)]
                    if any(actual[i]==actual[i+1] for i in range(3)): continue
                    S={(x,y) for x,y in expanded if y>=0}
                    if len(S)<2 or len(S)>13: continue
                    key=norm_trace(S)
                    if key is None: continue
                    generated+=1
                    traces.setdefault(key, {'S':set(key), 'witness_endpoints':endpoints})
    rows=[]; admissible=0; max_excess=-999.0
    for key,rec in traces.items():
        S=rec['S']
        sol=exact_min_internal_turns(S,U)
        if not isfinite(sol.cost): continue
        admissible+=1
        excess=float(sol.cost) - 2.0*len(S)/3.0
        max_excess=max(max_excess,excess)
        rows.append({'n_vertices':len(S),'exact_KH':int(sol.cost),'excess_over_2n_over_3':round(excess,6)})
    summary={
        'convention':'exactly four compressed links; U1; link lengths 1..2; start x=0, y in [-3,3]; horizontal-translation trace normalization; n<=13',
        'generated_paths_after_simple_filters':generated,
        'distinct_normalized_traces':len(traces),
        'admissible_traces':admissible,
        'max_exact_KH_minus_2n_over_3':round(max_excess,6) if rows else None,
    }
    (ROOT/'data'/'phase6_four_link_scan.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2)+'\n',encoding='utf-8')
    with (ROOT/'data'/'phase6_four_link_scan_summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['metric','value']); [w.writerow([k,v]) for k,v in summary.items()]
    print(json.dumps(summary,indent=2))
    print('PHASE6_FOUR_LINK_SCAN_PASS')

if __name__=='__main__': main()
