#!/usr/bin/env python3
"""Connectivity-aware finite-state certificate for triangular strips.

This is a proof certificate, not a heuristic regression.

A cut of the two-row unit-triangular strip has three possible crossing edges
(a,b,c).  A state records:
  * e in {0,1,2}: number of global Hamiltonian endpoints already in the
    processed prefix;
  * crossing mask;
  * which crossing stubs are paired through the processed prefix;
  * which crossing stubs are attached to endpoint labels E0,E1.

All processed vertices are required to have degree 2.  Transitions forbid a
closed component before the final boundary.  Hence the state contains the
connectivity information missing from the old four-state parity automaton.

The generated max-plus matrix A satisfies the finite certificate
    supp(A^6) subset supp(A^3)
    A^6 >= A^3 + 2  on every finite entry of A^3.
Consequently for every feasible state pair and every n>=6,
    F_n >= F_{n-3}+2,
with feasibility also descending by three.  Base lengths 0..5 give the
uniform bound
    F_n >= 2n/3 - 7/3,
where F_n is the maximum number of straight rail vertices in an n-column
transfer with the prescribed connectivity states.
"""
from __future__ import annotations
from itertools import combinations
from fractions import Fraction
from pathlib import Path
import csv, json

HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]
NEG=-10**9

# State tuple: (e, mask, pairs, unpaired)
# pairs = tuple of pairs of stub ids in {0,1,2}; unpaired[j] is stub connected
# to global endpoint Ej.  Endpoint identities are canonicalized when e=2.
def all_states():
    out=[]
    # e=0: exactly one pair crossing the cut
    for comb in combinations(range(3),2):
        out.append((0, sum(1<<x for x in comb), (tuple(sorted(comb)),), ()))
    # e=1: either one crossing stub, or three with one endpoint-stub + pair
    for x in range(3):
        out.append((1,1<<x,(),(x,)))
    for u in range(3):
        pair=tuple(x for x in range(3) if x!=u)
        out.append((1,7,(tuple(sorted(pair)),),(u,)))
    # e=2: two crossing stubs, each attached to one global endpoint.
    for comb in combinations(range(3),2):
        out.append((2,sum(1<<x for x in comb),(),tuple(sorted(comb))))
    return out

STATES=all_states(); INDEX={s:i for i,s in enumerate(STATES)}

class DSU:
    def __init__(self): self.p={}
    def add(self,x): self.p.setdefault(x,x)
    def find(self,x):
        self.add(x)
        if self.p[x]!=x: self.p[x]=self.find(self.p[x])
        return self.p[x]
    def union(self,a,b):
        ra,rb=self.find(a),self.find(b)
        if ra!=rb:self.p[rb]=ra

def transition(left, rmask, vertical):
    """Return (right_state,reward) or None.

    Crossing stub ids: 0=a rail A, 1=b rail B, 2=c diagonal A_i-B_{i+1}.
    A transition processes the two vertices A_i,B_i.  Reward is the number
    of those two vertices that are straight along a rail.
    """
    e,lmask,pairs,un=left
    la,lb,lc=((lmask>>k)&1 for k in range(3))
    ra,rb,rc=((rmask>>k)&1 for k in range(3))
    # Internal degree two at A_i and B_i.
    if la+vertical+ra+rc != 2: return None
    if lb+lc+vertical+rb != 2: return None

    d=DSU(); A=('V','A'); B=('V','B'); d.add(A); d.add(B)
    for j in range(e):d.add(('E',j))
    for k in range(3):
        if (lmask>>k)&1:d.add(('L',k))
        if (rmask>>k)&1:d.add(('R',k))
    for x,y in pairs:d.union(('L',x),('L',y))
    for j,stub in enumerate(un):d.union(('E',j),('L',stub))
    if la:d.union(('L',0),A)
    if lb:d.union(('L',1),B)
    if lc:d.union(('L',2),B)
    if ra:d.union(('R',0),A)
    if rb:d.union(('R',1),B)
    if rc:d.union(('R',2),A)
    if vertical:d.union(A,B)

    comps={}
    for node in list(d.p):comps.setdefault(d.find(node),[]).append(node)
    rpairs=[]; run=[None]*e
    for nodes in comps.values():
        terms=[x for x in nodes if isinstance(x,tuple) and x[0] in ('R','E')]
        # A linear-forest component must retain exactly two terminals.  Zero
        # terminals is a prematurely closed component/cycle; >2 would branch.
        if len(terms)!=2:return None
        Rs=[x[1] for x in terms if x[0]=='R']
        Es=[x[1] for x in terms if x[0]=='E']
        if len(Rs)==2 and not Es:
            rpairs.append(tuple(sorted(Rs)))
        elif len(Rs)==1 and len(Es)==1:
            run[Es[0]]=Rs[0]
        else:
            # two endpoints joined before the final boundary, or other invalid
            # connectivity.
            return None
    if any(x is None for x in run):return None
    right=(e,rmask,tuple(sorted(rpairs)),tuple(run))
    if right not in INDEX:return None
    reward=int(la and ra)+int(lb and rb)
    return right,reward

def build_transitions():
    T={s:[] for s in STATES}
    for s in STATES:
        for rmask in range(1,8):
            for vertical in (0,1):
                z=transition(s,rmask,vertical)
                if z is not None and z not in T[s]:T[s].append(z)
    return T
TRANS=build_transitions()

def maxplus_mul(X,Y):
    n=len(X); Z=[[NEG]*n for _ in range(n)]
    for i in range(n):
        for k in range(n):
            if X[i][k]<=NEG//2:continue
            for j in range(n):
                if Y[k][j]<=NEG//2:continue
                Z[i][j]=max(Z[i][j],X[i][k]+Y[k][j])
    return Z

def matrix_A():
    n=len(STATES); A=[[NEG]*n for _ in range(n)]
    for s,outs in TRANS.items():
        i=INDEX[s]
        for t,w in outs:A[i][INDEX[t]]=max(A[i][INDEX[t]],w)
    return A

def mp_pow(A,k):
    n=len(A); I=[[NEG]*n for _ in range(n)]
    for i in range(n):I[i][i]=0
    R=I
    for _ in range(k):R=maxplus_mul(R,A)
    return R

def fmt_state(s):
    e,mask,pairs,un=s
    crossings=''.join('abc'[k] for k in range(3) if mask>>k&1)
    pairtxt=';'.join(''.join('abc'[x] for x in p) for p in pairs) or '-'
    untxt=';'.join(f'E{j}-'+ 'abc'[x] for j,x in enumerate(un)) or '-'
    return f'e={e}|X={crossings}|pairs={pairtxt}|end={untxt}'

def main():
    A=matrix_A(); A3=mp_pow(A,3); A6=mp_pow(A,6)
    # Finite proof certificate.
    support_ok=True; weight_ok=True; violations=[]
    for i in range(len(STATES)):
        for j in range(len(STATES)):
            if A6[i][j]>NEG//2 and A3[i][j]<=NEG//2:
                support_ok=False;violations.append(('support',i,j,A3[i][j],A6[i][j]))
            if A3[i][j]>NEG//2 and A6[i][j] < A3[i][j]+2:
                weight_ok=False;violations.append(('weight',i,j,A3[i][j],A6[i][j]))
    if not (support_ok and weight_ok):
        raise AssertionError(violations[:10])

    # Exact base deficit at n=0..5.
    base=[]; max_def=Fraction(-999,1); max_arg=None
    for n in range(6):
        An=mp_pow(A,n)
        for i in range(len(STATES)):
            for j in range(len(STATES)):
                if An[i][j]<=NEG//2:continue
                deficit=Fraction(2*n,3)-An[i][j]
                if deficit>max_def:
                    max_def=deficit;max_arg=(n,i,j,An[i][j])
        base.append({'n':n,'worst_deficit':str(max(Fraction(2*n,3)-An[i][j]
                    for i in range(len(STATES)) for j in range(len(STATES)) if An[i][j]>NEG//2))})
    if max_def != Fraction(7,3):
        raise AssertionError((max_def,max_arg))

    # Independent finite-range consequence check; not needed for proof.
    for n in range(0,61):
        An=mp_pow(A,n)
        for i in range(len(STATES)):
            for j in range(len(STATES)):
                if An[i][j]<=NEG//2:continue
                if Fraction(An[i][j],1) < Fraction(2*n,3)-Fraction(7,3):
                    raise AssertionError(('bound',n,i,j,An[i][j]))

    # State/transition tables.
    with (ROOT/'data'/'connectivity_strip_states.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['state_id','state'])
        for i,s in enumerate(STATES):w.writerow([i,fmt_state(s)])
    with (ROOT/'data'/'connectivity_strip_transitions.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['from_id','to_id','reward_straight','from_state','to_state'])
        for s in STATES:
            for t,reward in TRANS[s]:
                w.writerow([INDEX[s],INDEX[t],reward,fmt_state(s),fmt_state(t)])

    cert={
        'number_of_states':len(STATES),
        'number_of_transitions':sum(len(v) for v in TRANS.values()),
        'certificate':{
            'support_A6_subset_support_A3':support_ok,
            'A6_ge_A3_plus_2_on_support_A3':weight_ok,
            'logical_consequence':'For every feasible connectivity state pair, feasibility descends by 3 for lengths >=6 and optimum straight reward increases by at least 2 per +3 columns.',
            'base_lengths_checked':[0,1,2,3,4,5],
            'uniform_straight_bound':'F_n(s,t) >= 2n/3 - 7/3 for every feasible state pair and n>=0',
            'uniform_turn_bound':'turns on 2n clean slab vertices <= 4n/3 + 7/3 = (2/3)(2n)+7/3',
            'worst_base_deficit':str(max_def),
            'worst_base_case':{'n':max_arg[0],'from_state':max_arg[1],'to_state':max_arg[2],'straight_reward':max_arg[3]},
        },
        'base_deficits':base,
    }
    (ROOT/'data'/'connectivity_strip_certificate.json').write_text(json.dumps(cert,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(cert['certificate'],indent=2))
    print('CONNECTIVITY_STRIP_CERTIFICATE_PASS')

if __name__=='__main__':main()
