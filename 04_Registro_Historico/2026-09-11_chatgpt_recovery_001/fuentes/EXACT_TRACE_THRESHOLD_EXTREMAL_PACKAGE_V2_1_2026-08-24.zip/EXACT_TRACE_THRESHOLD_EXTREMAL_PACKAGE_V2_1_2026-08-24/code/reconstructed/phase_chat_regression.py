#!/usr/bin/env python3
"""RECONSTRUCTED FROM CHAT DESCRIPTION.

Finite regression checks for explicit families discussed after Paper IIII.
This script is not an original development artifact and is not part of any proof.
It reuses the exact primitive-step model and dynamic-programming solver preserved
under code/original_paper_iiii/.
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[2]
ORIGINAL_SRC = ROOT / "code" / "original_paper_iiii" / "src"
sys.path.insert(0, str(ORIGINAL_SRC))

from exact_trace_confinement import (  # type: ignore
    count_turns,
    exact_min_internal_turns,
    validate_free_witness,
)


def rect_threshold(t: int):
    S = {(i, 1) for i in range(t + 1)} | {(i, 2) for i in range(t + 1)} | {(0, 0), (t, 0)}
    W = [(0, 2), (t, 2), (t, -1), (0, -1), (0, 1), (t - 1, 1)]
    U = [(1, 0), (0, 1)]
    return S, W, U, {"expected_KH": 2 * t, "claimed_Kfree": 4}


def rect_extremal(t: int):
    S = {(i, 1) for i in range(t + 1)} | {(i, 2) for i in range(1, t + 1)} | {(0, 0), (t, 0)}
    W = [(t - 1, 1), (0, 1), (0, -1), (t, -1), (t, 2), (1, 2)]
    U = [(1, 0), (0, 1)]
    return S, W, U, {"expected_KH": len(S) - 3, "claimed_Kfree": 4}


def u1_three_turn(n: int):
    S = (
        {(0, i) for i in range(n + 1)}
        | {(1, j) for j in range(1, n + 3)}
        | {(2, 0), (2, 1), (3, 1)}
    )
    W = [(0, n), (0, -2), (3, 1), (1, 1), (1, n + 2)]
    U = [(1, 0), (0, 1), (1, 1)]
    return S, W, U, {"expected_KH": None, "claimed_Kfree": 3}


def u12_extremal(p: int):
    S = (
        {(i, 2 * i + 1) for i in range(p + 1)}
        | {(j - 2, 2 * j - 1) for j in range(1, p + 1)}
        | {(0, 0)}
    )
    W = [(p, 2 * p + 1), (0, 1), (0, -1), (-2, -1), (p - 2, 2 * p - 1)]
    U = [(1, 0), (0, 1), (1, 1), (1, 2)]
    return S, W, U, {"expected_KH": len(S) - 2, "claimed_Kfree": 3}


def u23_extremal(p: int):
    S = (
        {(i, 3 * i + 1) for i in range(p + 1)}
        | {(j, 3 * j - 2) for j in range(1, p + 1)}
        | {(0, 0)}
    )
    W = [(p, 3 * p + 1), (0, 1), (0, -2), (p, 3 * p - 2)]
    U = [(1, 0), (0, 1), (1, 2), (1, 3)]
    return S, W, U, {"expected_KH": len(S) - 2, "claimed_Kfree": 2}


def um_extremal(m: int, p: int):
    K = m + 1
    S = (
        {(i, K * i + 1) for i in range(p + 1)}
        | {(j, K * j - K + 1) for j in range(1, p + 1)}
        | {(0, 0)}
    )
    W = [(p, K * p + 1), (0, 1), (0, 1 - K), (p, K * p - K + 1)]
    U = [(1, 0), (0, 1), (1, m), (1, m + 1)]
    return S, W, U, {"expected_KH": len(S) - 2, "claimed_Kfree": 2}


def top_gap(J: set[int], p: int):
    K = max(J)
    a = max([0] + [j for j in J if j < K])
    g = K - a
    if g < 2:
        raise ValueError("top_gap requires K-a >= 2")
    r = g - 1
    S = (
        {(i, r + K * i) for i in range(p + 1)}
        | {(j, -1 + K * j) for j in range(1, p + 1)}
        | {(0, y) for y in range(r)}
    )
    W = [(p, r + K * p), (0, r), (0, -1), (p, -1 + K * p)]
    U = [(1, 0), (0, 1)] + [(1, j) for j in sorted(J)]
    return S, W, U, {"expected_KH": 2 * p, "claimed_Kfree": 2}


def full_initial_block(K: int, p: int):
    g = K - 1
    S = (
        {(i, i) for i in range(p + 1)}
        | {(j, j - g) for j in range(g, p - 1)}
    )
    W = [(p, p), (-1, -1), (-1, -K), (p - 2, p - 2 - g)]
    U = [(1, 0), (0, 1)] + [(1, j) for j in range(1, K + 1)]
    return S, W, U, {"expected_KH": None, "claimed_Kfree": 2}


def evaluate(name: str, parameter: str, S, W, U, meta):
    expanded = validate_free_witness(S, W, U)
    witness_turns = count_turns(expanded)
    sol = exact_min_internal_turns(S, U)
    expected = meta["expected_KH"]
    if expected is not None and sol.cost != expected:
        raise AssertionError(f"{name} {parameter}: expected KH={expected}, got {sol.cost}")
    return {
        "family": name,
        "parameter": parameter,
        "n_vertices": len(S),
        "free_witness_turns": witness_turns,
        "claimed_Kfree": meta["claimed_Kfree"],
        "exact_KH": sol.cost,
        "expected_KH": expected,
        "dp_states": sol.states,
        "free_trace_valid": True,
    }


def main():
    rows = []
    for t in (3, 5, 7):
        rows.append(evaluate("rect_threshold", f"t={t}", *rect_threshold(t)))
    for t in (2, 4, 6):
        rows.append(evaluate("rect_extremal", f"t={t}", *rect_extremal(t)))
    for n in range(2, 13):
        rows.append(evaluate("U1_three_turn", f"n={n}", *u1_three_turn(n)))
    for p in (2, 4, 6):
        rows.append(evaluate("U12_extremal", f"p={p}", *u12_extremal(p)))
        rows.append(evaluate("U23_extremal", f"p={p}", *u23_extremal(p)))
    for m in (2, 3, 4):
        for p in (2, 4):
            rows.append(evaluate("Um_mplus1_extremal", f"m={m};p={p}", *um_extremal(m, p)))
    for J in ({2}, {1, 3}, {1, 2, 4}):
        for p in (2, 4, 6):
            rows.append(evaluate("top_gap_repaired", f"J={sorted(J)};p={p}", *top_gap(J, p)))
    for K in (3, 4):
        g = K - 1
        for p in (g + 5, g + 7):  # p-g odd; admissible branch
            rows.append(evaluate("full_initial_block", f"K={K};p={p}", *full_initial_block(K, p)))

    out_csv = ROOT / "data" / "phase_chat_regression.csv"
    out_json = ROOT / "data" / "phase_chat_regression.json"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    out_json.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"WROTE {out_csv}")
    print(f"WROTE {out_json}")
    print("CHAT_PHASE_REGRESSION_PASS")


if __name__ == "__main__":
    main()
