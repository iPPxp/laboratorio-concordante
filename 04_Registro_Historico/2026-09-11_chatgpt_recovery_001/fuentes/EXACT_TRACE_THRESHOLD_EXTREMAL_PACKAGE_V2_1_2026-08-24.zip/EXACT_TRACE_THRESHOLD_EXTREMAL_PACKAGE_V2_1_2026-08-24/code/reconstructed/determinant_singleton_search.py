#!/usr/bin/env python3
"""RECONSTRUCTED FROM CHAT DESCRIPTION.

Exhaustive finite search for the singleton determinant-class bottleneck.
Evidence only; never a proof of the unbounded statement.
"""
from __future__ import annotations

import csv
import json
from itertools import combinations
from math import gcd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def primitive_unoriented(bound: int):
    out = []
    for x in range(-bound, bound + 1):
        for y in range(-bound, bound + 1):
            if x == 0 and y == 0:
                continue
            if gcd(abs(x), abs(y)) != 1:
                continue
            if x < 0 or (x == 0 and y < 0):
                continue
            out.append((x, y))
    return sorted(out)


def det(a, b):
    return a[0] * b[1] - a[1] * b[0]


def singleton_certificate(S):
    for r in S:
        counts = {}
        for w in S:
            if w == r:
                continue
            d = abs(det(r, w))
            if d == 0:
                continue
            counts[d] = counts.get(d, 0) + 1
        for delta, multiplicity in counts.items():
            if multiplicity == 1:
                return r, delta
    return None


def main():
    D = primitive_unoriented(5)
    if len(D) != 40:
        raise AssertionError(f"expected 40 normalized directions, got {len(D)}")
    summary = []
    counterexamples = []
    for k in (4, 5):
        checked = 0
        no_singleton = 0
        for S in combinations(D, k):
            checked += 1
            if singleton_certificate(S) is None:
                no_singleton += 1
                counterexamples.append({"k": k, "set": S})
        summary.append({"k": k, "checked": checked, "no_singleton": no_singleton})
    if summary[0]["checked"] != 91390 or summary[1]["checked"] != 658008:
        raise AssertionError(summary)

    (ROOT / "data" / "determinant_singleton_summary.json").write_text(
        json.dumps({"bound": 5, "directions": D, "summary": summary, "counterexamples": counterexamples}, indent=2) + "\n",
        encoding="utf-8",
    )
    with (ROOT / "data" / "determinant_singleton_summary.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["k", "checked", "no_singleton"])
        w.writeheader(); w.writerows(summary)
    print(summary)
    print("DETERMINANT_SINGLETON_SEARCH_PASS")


if __name__ == "__main__":
    main()
