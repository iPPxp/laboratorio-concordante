# Online Resource 1 - Reproducibility package

**Article:** *Unbounded Exact-Trace Confinement Gaps for Finite-Direction Lattice Spanning Paths*  
**Journal:** *Discrete & Computational Geometry* (submission package)  
**Author:** Jorge Rosales Pérez  
**Affiliation:** Independent Researcher, Mérida, Yucatán, Mexico  
**Corresponding author:** mtro.jrp@gmail.com  
**ORCID:** 0009-0008-1679-7858

## Purpose

This supplementary package provides finite computational regression checks for the manuscript. The formal proofs in the article are self-contained and do not depend on the computations here.

The package contains:

- a deterministic implementation of the primitive-step exact-trace model;
- an exact finite-instance dynamic-programming solver for minimum internal turns;
- an independent structural verifier for the dense family `R_p`;
- regression checks for the dense family and finite generic/pencil comparison instances;
- deterministic CSV/JSON result tables;
- a SHA-256 manifest.

## Requirements

- Python 3.10 or later
- Python standard library only

## Reproduce

From the directory containing this README:

```bash
python reproduce.py
```

A successful run ends with:

```text
ONLINE_RESOURCE_1_REPRODUCTION_PASS
```

The structural verifier checks the exact `R_p` graph pattern and turn formula for every even `p` from 4 through 100. The dynamic-programming checks are finite regression tests and are not used as proof of the universal theorem.

## Files

- `src/exact_trace_confinement.py` - exact model, witnesses, graph construction, and finite solver.
- `src/generate_data.py` - deterministic result-table generation.
- `tests/verify_structural.py` - independent structural verification of the dense family.
- `tests/verify_regression.py` - finite exact regression checks for the manuscript constructions.
- `data/results.csv`, `data/results.json` - generated finite results.
- `SHA256SUMS.txt` - integrity manifest.

## License

Documentation and generated data: CC BY 4.0. Source code: MIT License. Copyright (c) 2026 Jorge Rosales Pérez.
