"""Cross-platform reproduction entry point (Python 3.10+, standard library only)."""
from __future__ import annotations
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
commands=[
    [sys.executable,"src/generate_data.py"],
    [sys.executable,"tests/verify_structural.py"],
    [sys.executable,"tests/verify_regression.py"],
    [sys.executable,"src/verify_hashes.py"],
]
for cmd in commands:
    print("+"," ".join(cmd)); subprocess.run(cmd,cwd=ROOT,check=True)
print("ONLINE_RESOURCE_1_REPRODUCTION_PASS")
