"""Exact finite regression checks supporting (but not proving) the manuscript."""
from __future__ import annotations
import sys
from math import inf
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from exact_trace_confinement import (DENSE_DIRECTIONS, count_turns, exact_min_internal_turns,
    generic_rail_family, generic_rail_free_witness, generic_rail_internal_witness,
    linear_image, linear_image_walk, pencil_family, pencil_free_witness,
    pencil_internal_witness, q_family, q_free_witness, q_internal_witness,
    rail_family, rail_free_witness, rail_internal_witness, validate_free_witness,
    validate_internal_walk)

def main() -> None:
    for p in range(4,15,2):
        points=rail_family(p)
        free=validate_free_witness(points,rail_free_witness(p))
        assert count_turns(free)==2
        sol=exact_min_internal_turns(points)
        assert sol.cost==2*p-4
        assert sol.witness is not None
        validate_internal_walk(points,sol.witness)
        validate_internal_walk(points,rail_internal_witness(p))
    generic_samples=[
        (((2,1),(1,1),(0,1)),(2,1),(-1,-1),(5,7,9)),
        (DENSE_DIRECTIONS,(2,1),(-1,-2),(4,6,8,10)),
    ]
    for alphabet,v,s,params in generic_samples:
        prev=-1.0
        for p in params:
            points=generic_rail_family(v,s,p)
            validate_free_witness(points,generic_rail_free_witness(v,s,p),alphabet)
            internal=generic_rail_internal_witness(v,s,p)
            validate_internal_walk(points,internal,alphabet)
            exact=exact_min_internal_turns(points,alphabet)
            assert exact.cost < inf and exact.cost >= prev
            prev=exact.cost
    for mask in range(1,1<<3):
        slopes=[k for k in range(1,4) if mask & (1<<(k-1))]
        K=max(slopes); alphabet=((1,0),(0,1),*((1,k) for k in slopes))
        prev=-1.0
        for p in (4,6,8,10):
            points=pencil_family(K,p)
            validate_free_witness(points,pencil_free_witness(K,p),alphabet)
            validate_internal_walk(points,pencil_internal_witness(K,p),alphabet)
            exact=exact_min_internal_turns(points,alphabet)
            assert exact.cost < inf and exact.cost >= prev
            prev=exact.cost
    abstract=((1,0),(0,1)); h,v=(-1,0),(2,1); physical=(h,v)
    for t in (4,6,8):
        q=q_family(t); iw=q_internal_witness(t)
        validate_internal_walk(q,iw,abstract); assert count_turns(iw)==2*t
        assert exact_min_internal_turns(q,abstract).cost==2*t
        pq=linear_image(q,h,v)
        pf=linear_image_walk(q_free_witness(t),h,v)
        pi=linear_image_walk(iw,h,v)
        validate_free_witness(pq,pf,physical); validate_internal_walk(pq,pi,physical)
        assert exact_min_internal_turns(pq,physical).cost==2*t
    print("ALL_REGRESSION_ASSERTIONS_PASS")
if __name__ == "__main__": main()
