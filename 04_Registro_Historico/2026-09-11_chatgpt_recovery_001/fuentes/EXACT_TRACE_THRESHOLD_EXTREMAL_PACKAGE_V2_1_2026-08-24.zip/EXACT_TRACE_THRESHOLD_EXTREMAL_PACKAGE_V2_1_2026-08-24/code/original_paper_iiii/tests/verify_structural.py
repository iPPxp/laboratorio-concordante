"""Independent structural verifier for Theorem 3.1 (the dense R_p family)."""
from __future__ import annotations
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from exact_trace_confinement import (actual_edges, certifies_no_at_most_one_turn_cover,
    count_turns, expected_rail_edges, induced_primitive_graph, rail_family,
    rail_free_witness, rail_internal_witness, validate_free_witness, validate_internal_walk)

def main() -> None:
    for p in range(4,101,2):
        points=rail_family(p)
        assert len(points)==2*p-1
        graph=induced_primitive_graph(points)
        assert actual_edges(graph)==expected_rail_edges(p)
        leaves=sorted(q for q,neigh in graph.items() if len(neigh)==1)
        assert leaves==[(0,p),(p,0)]
        internal=rail_internal_witness(p)
        validate_internal_walk(points,internal)
        assert count_turns(internal)==2*p-4
        free=rail_free_witness(p)
        expanded=validate_free_witness(points,free)
        assert count_turns(expanded)==2
        assert certifies_no_at_most_one_turn_cover(points)
    print("STRUCTURAL_VERIFIER_PASS p=4..100 even")
if __name__ == "__main__": main()
