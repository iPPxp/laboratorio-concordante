from __future__ import annotations
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXCLUDE={Path("SHA256SUMS.txt"),Path("__pycache__")}
def files():
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT)
        if rel==Path("SHA256SUMS.txt") or "__pycache__" in rel.parts: continue
        yield p,rel
lines=[]
for p,rel in files(): lines.append(f"{sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}")
(ROOT/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8",newline="\n")
print(f"HASH_MANIFEST_WRITTEN files={len(lines)}")
