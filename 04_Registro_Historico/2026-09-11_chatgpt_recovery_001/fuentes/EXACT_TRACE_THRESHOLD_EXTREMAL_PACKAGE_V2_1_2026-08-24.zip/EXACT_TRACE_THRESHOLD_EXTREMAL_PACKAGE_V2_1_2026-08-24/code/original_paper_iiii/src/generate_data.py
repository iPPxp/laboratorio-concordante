"""Regenerate deterministic finite verification tables for the manuscript."""
from __future__ import annotations
import csv, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from exact_trace_confinement import (DENSE_DIRECTIONS, count_turns, exact_min_internal_turns,
    instance_sha256, q_family, q_free_witness, q_internal_witness, rail_family,
    rail_free_witness, rail_internal_witness, validate_free_witness, validate_internal_walk)

def main() -> None:
    rows=[]
    for p in range(4, 15, 2):
        points=rail_family(p)
        free=validate_free_witness(points, rail_free_witness(p), DENSE_DIRECTIONS)
        internal=rail_internal_witness(p)
        validate_internal_walk(points, internal, DENSE_DIRECTIONS)
        sol=exact_min_internal_turns(points, DENSE_DIRECTIONS)
        rows.append({
            "family":"R_p", "parameter":p, "n":len(points),
            "K_free":count_turns(free), "K_H":int(sol.cost),
            "theorem_K_H":2*p-4, "dp_states":sol.states,
            "instance_sha256":instance_sha256(points, DENSE_DIRECTIONS),
        })
    hv=((1,0),(0,1))
    for t in (4,6,8):
        points=q_family(t)
        free=validate_free_witness(points, q_free_witness(t), hv)
        internal=q_internal_witness(t)
        validate_internal_walk(points, internal, hv)
        sol=exact_min_internal_turns(points, hv)
        rows.append({
            "family":"Q_t", "parameter":t, "n":len(points),
            "K_free":count_turns(free), "K_H":int(sol.cost),
            "theorem_K_H":2*t, "dp_states":sol.states,
            "instance_sha256":instance_sha256(points, hv),
        })
    data=ROOT/"data"; data.mkdir(exist_ok=True)
    (data/"results.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
    with (data/"results.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"GENERATED_RESULTS rows={len(rows)}")
if __name__ == "__main__": main()
