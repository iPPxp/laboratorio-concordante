from __future__ import annotations
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/"SHA256SUMS.txt"
count=0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    digest,rel=line.split("  ",1); p=ROOT/rel
    assert p.is_file(), f"missing: {rel}"
    actual=sha256(p.read_bytes()).hexdigest()
    assert actual==digest, f"hash mismatch: {rel}"
    count+=1
print(f"HASHES_PASS files={count}")
