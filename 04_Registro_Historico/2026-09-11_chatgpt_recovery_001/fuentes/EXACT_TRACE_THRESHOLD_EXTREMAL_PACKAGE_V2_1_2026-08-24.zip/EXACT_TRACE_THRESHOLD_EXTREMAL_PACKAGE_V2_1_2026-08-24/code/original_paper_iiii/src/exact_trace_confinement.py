"""Exact helpers for the reproducibility package accompanying the DCG manuscript.

The contract is intentionally strict:

* paths are vertex-simple;
* every edge is exactly one primitive alphabet step;
* long links are expanded before their trace is checked;
* the boundary y=0 belongs to the confined half-plane;
* direction classes are unoriented, so u and -u represent one direction.

Only the Python standard library is used.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from hashlib import sha256
from json import dumps
from math import gcd, inf
from typing import Iterable, Sequence

Point = tuple[int, int]
Direction = tuple[int, int]

U4: tuple[Direction, ...] = (
    (1, 0),
    (0, 1),
    (1, 1),
    (1, -1),
)

DENSE_DIRECTIONS: tuple[Direction, ...] = U4 + (
    (1, 2),
    (1, -2),
    (2, 1),
    (2, -1),
)


def canonical_direction(dx: int, dy: int) -> Direction:
    """Return the primitive unoriented representative of a displacement."""
    divisor = gcd(abs(dx), abs(dy))
    if divisor == 0:
        raise ValueError("zero displacement has no direction")
    dx, dy = dx // divisor, dy // divisor
    if dx < 0 or (dx == 0 and dy < 0):
        dx, dy = -dx, -dy
    return dx, dy


def direction_classes(
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> tuple[Direction, ...]:
    """Validate, canonicalize, deduplicate, and sort an alphabet."""
    classes: set[Direction] = set()
    for direction in directions:
        canonical = canonical_direction(*direction)
        if canonical != direction and canonical != (-direction[0], -direction[1]):
            raise ValueError(f"nonprimitive alphabet vector: {direction}")
        classes.add(canonical)
    return tuple(sorted(classes))


def induced_primitive_graph(
    points: Iterable[Point],
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> dict[Point, dict[Point, int]]:
    """Build G_U(S), using equality with one primitive step, not collinearity."""
    classes = direction_classes(directions)
    class_id = {direction: index for index, direction in enumerate(classes)}
    point_set = set(points)
    graph: dict[Point, dict[Point, int]] = {point: {} for point in point_set}
    for x, y in point_set:
        for direction, label in class_id.items():
            dx, dy = direction
            for sign in (-1, 1):
                neighbor = x + sign * dx, y + sign * dy
                if neighbor in point_set:
                    graph[(x, y)][neighbor] = label
    return graph


def expand_link_endpoints(link_endpoints: Sequence[Point]) -> list[Point]:
    """Expand compressed integer links into all primitive lattice vertices."""
    if not link_endpoints:
        return []
    expanded = [link_endpoints[0]]
    for (x, y), (xx, yy) in zip(link_endpoints, link_endpoints[1:]):
        dx, dy = xx - x, yy - y
        steps = gcd(abs(dx), abs(dy))
        if steps == 0:
            raise ValueError("zero-length link")
        ux, uy = dx // steps, dy // steps
        expanded.extend((x + t * ux, y + t * uy) for t in range(1, steps + 1))
    return expanded


def count_turns(walk: Sequence[Point]) -> int:
    """Count changes of unoriented primitive direction."""
    if len(walk) < 2:
        return 0
    directions = [
        canonical_direction(xx - x, yy - y)
        for (x, y), (xx, yy) in zip(walk, walk[1:])
    ]
    return sum(one != two for one, two in zip(directions, directions[1:]))


def validate_internal_walk(
    points: Iterable[Point],
    walk: Sequence[Point],
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> None:
    """Reject a walk unless it is a simple exact internal witness."""
    point_set = set(points)
    if len(walk) != len(set(walk)):
        raise AssertionError("internal witness repeats a vertex")
    if set(walk) != point_set:
        raise AssertionError("internal witness does not have exact trace S")
    graph = induced_primitive_graph(point_set, directions)
    for one, two in zip(walk, walk[1:]):
        if two not in graph[one]:
            raise AssertionError(f"forbidden primitive step: {one} -> {two}")


def validate_free_witness(
    points: Iterable[Point],
    link_endpoints: Sequence[Point],
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> list[Point]:
    """Expand and validate a simple free witness with exact y>=0 trace."""
    allowed = set(direction_classes(directions))
    expanded = expand_link_endpoints(link_endpoints)
    if len(expanded) != len(set(expanded)):
        raise AssertionError("free witness repeats a vertex")
    for one, two in zip(link_endpoints, link_endpoints[1:]):
        direction = canonical_direction(two[0] - one[0], two[1] - one[1])
        if direction not in allowed:
            raise AssertionError(f"forbidden free link: {one} -> {two}")
    visible = {point for point in expanded if point[1] >= 0}
    if visible != set(points):
        missing = set(points) - visible
        extra = visible - set(points)
        raise AssertionError(f"wrong free trace; missing={missing}, extra={extra}")
    return expanded


@dataclass(frozen=True)
class InternalSolution:
    cost: float
    states: int
    witness: tuple[Point, ...] | None


def exact_min_internal_turns(
    points: Iterable[Point],
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> InternalSolution:
    """Exact 0-1 BFS on (visited mask, endpoint, last direction).

    Infinity means that no vertex-simple Hamiltonian path exists.
    """
    graph_by_point = induced_primitive_graph(points, directions)
    vertices = sorted(graph_by_point)
    if not vertices:
        return InternalSolution(inf, 0, None)
    if len(vertices) == 1:
        return InternalSolution(0, 1, (vertices[0],))
    index = {point: i for i, point in enumerate(vertices)}
    graph = [
        [(index[q], label) for q, label in graph_by_point[point].items()]
        for point in vertices
    ]
    full_mask = (1 << len(vertices)) - 1
    distance: dict[tuple[int, int, int], int] = {}
    parent: dict[tuple[int, int, int], tuple[int, int, int] | None] = {}
    origin: dict[tuple[int, int, int], int] = {}
    queue: deque[tuple[tuple[int, int, int], int]] = deque()
    for start, neighbors in enumerate(graph):
        for endpoint, direction in neighbors:
            state = ((1 << start) | (1 << endpoint), endpoint, direction)
            if state in distance:
                continue
            distance[state] = 0
            parent[state] = None
            origin[state] = start
            queue.append((state, 0))

    final_state: tuple[int, int, int] | None = None
    while queue:
        state, value = queue.popleft()
        if value != distance.get(state):
            continue
        mask, endpoint, last_direction = state
        if mask == full_mask:
            final_state = state
            break
        for nxt, direction in graph[endpoint]:
            bit = 1 << nxt
            if mask & bit:
                continue
            new_state = (mask | bit, nxt, direction)
            increment = int(last_direction != -1 and direction != last_direction)
            new_value = value + increment
            if new_value >= distance.get(new_state, 10**18):
                continue
            distance[new_state] = new_value
            parent[new_state] = state
            if increment == 0:
                queue.appendleft((new_state, new_value))
            else:
                queue.append((new_state, new_value))

    if final_state is None:
        return InternalSolution(inf, len(distance), None)

    reversed_indices: list[int] = []
    cursor: tuple[int, int, int] | None = final_state
    initial_state: tuple[int, int, int] | None = None
    while cursor is not None:
        reversed_indices.append(cursor[1])
        if parent[cursor] is None:
            initial_state = cursor
        cursor = parent[cursor]
    assert initial_state is not None
    reversed_indices.append(origin[initial_state])
    reversed_indices.reverse()
    witness = tuple(vertices[i] for i in reversed_indices)
    return InternalSolution(float(distance[final_state]), len(distance), witness)


def rail_family(p: int) -> set[Point]:
    if p < 4:
        raise ValueError("R_p starts at p=4")
    top = {(i, p - i) for i in range(p + 1)}
    bottom = {(j, p - 2 - j) for j in range(1, p - 1)}
    return top | bottom


def rail_free_witness(p: int) -> list[Point]:
    return [(0, p), (p + 2, -2), (p, -2), (1, p - 3)]


def rail_internal_witness(p: int) -> list[Point]:
    if p < 4 or p % 2:
        raise ValueError("the internal witness exists for even p >= 4")
    a = lambda i: (i, p - i)
    b = lambda j: (j, p - 2 - j)
    walk = [a(0), a(1)]
    for k in range(1, p // 2):
        walk.extend((a(2 * k), b(2 * k - 1), b(2 * k), a(2 * k + 1)))
    walk.append(a(p))
    return walk


def expected_rail_edges(p: int) -> set[frozenset[Point]]:
    a = lambda i: (i, p - i)
    b = lambda j: (j, p - 2 - j)
    edges = {frozenset((a(i), a(i + 1))) for i in range(p)}
    edges |= {frozenset((b(j), b(j + 1))) for j in range(1, p - 2)}
    edges |= {frozenset((a(j + 1), b(j))) for j in range(1, p - 1)}
    return edges


def actual_edges(graph: dict[Point, dict[Point, int]]) -> set[frozenset[Point]]:
    return {
        frozenset((one, two))
        for one, neighbors in graph.items()
        for two in neighbors
    }


def certifies_no_at_most_one_turn_cover(
    points: Iterable[Point],
    directions: Iterable[Direction] = DENSE_DIRECTIONS,
) -> bool:
    """Safe relaxed certificate excluding paths contained in <=2 supports.

    A candidate link is granted every target point on its entire support and
    interval/exterior restrictions are ignored. If even this relaxation cannot
    cover S by one support or by two meeting supports, K_free >= 2.
    """
    point_set = set(points)
    supports: list[tuple[Direction, int, set[Point]]] = []
    for dx, dy in direction_classes(directions):
        invariants = {-dy * x + dx * y for x, y in point_set}
        for invariant in invariants:
            covered = {
                (x, y)
                for x, y in point_set
                if -dy * x + dx * y == invariant
            }
            supports.append(((dx, dy), invariant, covered))
    for i, (first_direction, first_invariant, first_cover) in enumerate(supports):
        if first_cover == point_set:
            return False
        for second_direction, second_invariant, second_cover in supports[i:]:
            if first_cover | second_cover != point_set:
                continue
            if first_direction != second_direction:
                return False  # relaxed model grants an intersection
            if first_invariant == second_invariant:
                return False
            # Distinct parallel supports cannot meet at one turn.
    return True


def zipper(a: int) -> set[Point]:
    if a < 1:
        raise ValueError("a must be positive")
    column = {(0, j) for j in range(1, a + 2)}
    top = {(i, a + 1 - i) for i in range(1, a + 2)}
    bottom = {(i, a - 1 - i) for i in range(1, a)}
    return column | top | bottom


def zipper_free_witness(a: int) -> list[Point]:
    return [(0, 1), (0, a + 1), (a + 3, -2), (a + 1, -2), (1, a - 2)]


def x_dilate(points: Iterable[Point], factor: int) -> set[Point]:
    if factor < 1:
        raise ValueError("factor must be positive")
    return {(factor * x, y) for x, y in points}


def x_dilated_zipper_free_witness(a: int, factor: int) -> list[Point]:
    return [(factor * x, y) for x, y in zipper_free_witness(a)]


def instance_sha256(
    points: Iterable[Point], directions: Iterable[Direction]
) -> str:
    payload = {
        "directions": direction_classes(directions),
        "points": sorted(set(points)),
    }
    encoded = dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256(encoded).hexdigest()


def add_points(one: Point, two: Point) -> Point:
    return one[0] + two[0], one[1] + two[1]


def scale_point(multiplier: int, point: Point) -> Point:
    return multiplier * point[0], multiplier * point[1]


def generic_rail_delta(v: Direction, s: Direction) -> int:
    """First i for which B_i=i*v+s lies in y>=0."""
    if v[1] <= 0 or s[1] >= 0:
        raise ValueError("generic rail normalization requires v_y>0 and s_y<0")
    return (-s[1] + v[1] - 1) // v[1]


def generic_rail_family(v: Direction, s: Direction, p: int) -> set[Point]:
    """The generic universal-case rails A_0..A_p and B_delta..B_(p-1)."""
    delta = generic_rail_delta(v, s)
    if p <= delta or (p - delta) % 2:
        raise ValueError("choose p>delta with p-delta even")
    a = lambda i: scale_point(i, v)
    b = lambda i: add_points(scale_point(i, v), s)
    return {a(i) for i in range(p + 1)} | {b(i) for i in range(delta, p)}


def generic_rail_free_witness(v: Direction, s: Direction, p: int) -> list[Point]:
    delta = generic_rail_delta(v, s)
    if p <= delta or (p - delta) % 2:
        raise ValueError("choose p>delta with p-delta even")
    a = lambda i: scale_point(i, v)
    b = lambda i: add_points(scale_point(i, v), s)
    return [a(p), a(-1), b(-1), b(p - 1)]


def generic_rail_internal_witness(v: Direction, s: Direction, p: int) -> list[Point]:
    delta = generic_rail_delta(v, s)
    if p <= delta or (p - delta) % 2:
        raise ValueError("choose p>delta with p-delta even")
    a = lambda i: scale_point(i, v)
    b = lambda i: add_points(scale_point(i, v), s)
    walk = [a(i) for i in range(delta + 1)]
    for offset in range(0, p - delta, 2):
        i = delta + offset
        walk.extend((b(i), b(i + 1), a(i + 1), a(i + 2)))
    return walk


def pencil_family(max_k: int, p: int) -> set[Point]:
    """Abstract-coordinate pencil family for H,V,{H+kV}."""
    if max_k < 1 or p < 4 or p % 2:
        raise ValueError("requires max_k>=1 and even p>=4")
    top = {(i, max_k) for i in range(p + 1)}
    bottom = {(j, 0) for j in range(1, p - 1)}
    cap = {(p, y) for y in range(max_k + 1)}
    return top | bottom | cap


def pencil_free_witness(max_k: int, p: int) -> list[Point]:
    if max_k < 1 or p < 4 or p % 2:
        raise ValueError("requires max_k>=1 and even p>=4")
    return [(0, max_k), (p, max_k), (p, -1), (1, -1), (1, 0), (p - 2, 0)]


def pencil_internal_witness(max_k: int, p: int) -> list[Point]:
    """R_p core using H+max_k*V rungs, followed by the pendant cap."""
    if max_k < 1 or p < 4 or p % 2:
        raise ValueError("requires max_k>=1 and even p>=4")
    a = lambda i: (i, max_k)
    b = lambda j: (j, 0)
    walk = [a(0), a(1)]
    for block in range(1, p // 2):
        walk.extend(
            (a(2 * block), b(2 * block - 1), b(2 * block), a(2 * block + 1))
        )
    walk.append(a(p))
    walk.extend((p, y) for y in range(max_k - 1, -1, -1))
    return walk


def q_family(t: int) -> set[Point]:
    """The two-direction Q_t family in abstract (H,V) coordinates."""
    if t < 4 or t % 2:
        raise ValueError("Q_t uses even t>=4")
    return (
        {(x, 1) for x in range(t + 1)}
        | {(x, 2) for x in range(t + 1)}
        | {(1, 0), (t, 0)}
    )


def q_free_witness(t: int) -> list[Point]:
    if t < 4 or t % 2:
        raise ValueError("Q_t uses even t>=4")
    return [(0, 1), (0, 2), (t, 2), (t, -1), (1, -1), (1, 1), (t - 1, 1)]


def q_internal_witness(t: int) -> list[Point]:
    """The forced Hamiltonian of Q_t for even t."""
    if t < 4 or t % 2:
        raise ValueError("Q_t uses even t>=4")
    middle = lambda i: (i, 1)
    top = lambda i: (i, 2)
    walk = [(1, 0), middle(1), middle(0), top(0), top(1)]
    for block in range(1, t // 2):
        walk.extend(
            (
                top(2 * block),
                middle(2 * block),
                middle(2 * block + 1),
                top(2 * block + 1),
            )
        )
    walk.extend((top(t), middle(t), (t, 0)))
    return walk


def linear_image(points: Iterable[Point], first: Direction, second: Direction) -> set[Point]:
    """Map abstract (i,j) to i*first+j*second."""
    return {
        add_points(scale_point(i, first), scale_point(j, second))
        for i, j in points
    }


def linear_image_walk(
    points: Sequence[Point], first: Direction, second: Direction
) -> list[Point]:
    return [
        add_points(scale_point(i, first), scale_point(j, second))
        for i, j in points
    ]
