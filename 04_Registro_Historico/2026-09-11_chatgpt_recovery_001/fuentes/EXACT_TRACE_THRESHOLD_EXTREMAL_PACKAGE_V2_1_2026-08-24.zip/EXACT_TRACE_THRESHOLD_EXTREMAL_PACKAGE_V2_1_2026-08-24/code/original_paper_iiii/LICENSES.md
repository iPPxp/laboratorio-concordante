# Licenses

- Documentation and generated data: Creative Commons Attribution 4.0 International (CC BY 4.0).
- Source code: MIT License.

Copyright (c) 2026 Jorge Rosales Pérez.
