# Paper I — revision after JNT decision

## Editorial input

Journal of Number Theory manuscript JNTH-D-26-01147 was declined on 25 August 2026. The decision stated that the manuscript was within scope but lacked sufficient novelty. No mathematical error, failed proof, incorrect computation, or literature defect was identified in the decision message.

## Revision principle

The theorem set is unchanged. The revision makes the paper’s model-specific contribution visible and separates it more sharply from classical Pell theory, standard unitary-divisor theory, middle-divisor literature, Eisenstein-lattice problems, and rational lattice-angle classification.

## Material changes

- Retitled the manuscript to foreground the exact boundary-contact spectrum, balanced unitary factorization, and consecutive Pell closure identity.
- Rewrote the abstract around the complete spectrum classification rather than around the geometric setup.
- Defined the boundary-contact closure spectrum explicitly in the introduction.
- Added a consolidated main structure theorem whose three parts point to the independently proved factorization, multiplicity, and Pell theorems.
- Added a direct explanation of why standard Pell approximation and the classical unitary-divisor count do not imply the paper’s closure statements.
- Clarified the distinct roles of exact computation: independent finite audit, first-collision minimality, and non-theorem exploratory scanning.
- Strengthened the discussion so the novelty claim concerns the compatibility of known arithmetic structures under a new exact closure invariant.
- Added MSC codes, keywords, affiliation, competing-interest disclosure, and a detailed generative-AI assistance declaration.

## Unchanged mathematical content

- \(r=2q-3p\) and \(\gcd(q,r)=\gcd(q,3)\).
- \(N=\operatorname{lcm}(q,r)\).
- Balanced coprime-factorization bijection.
- Exact multiplicity formula and bound.
- First collision at \(N=1260\).
- Complement involution.
- Negative-Pell consecutive-level theorem \(N'-N=1\).
- Cyclotomic comparison appendix.

## Verification

- LaTeX compilation: clean after three passes.
- Undefined references/citations: none.
- Overfull or underfull boxes: none reported.
- Exact verifier: PASS.
- Verified totals: 105,334 states; 96,768 occupied levels; first collision 1260.
- PDF visual inspection: 15 pages, all figures and equations rendered correctly.
