25 August 2026

Professor Alexander Kasprzyk  
Editor-in-Chief  
Experimental Mathematics

Dear Professor Kasprzyk,

Please consider the manuscript

“Exact Boundary-Contact Spectra in Equilateral Refinements: Balanced Unitary Factorizations and Consecutive Pell Closures”

for publication as an original research article in *Experimental Mathematics*.

The paper begins with an exact computational classification problem for the boundary contacts of a rotating six-ray frame in a uniformly refined equilateral triangle. The experiments expose two structures that are then proved without reliance on floating-point evidence:

1. a complete bijection between exact boundary-contact states and balanced coprime factorizations, turning closure-level multiplicity into a one-sided unitary middle-divisor count; and
2. an infinite negative-Pell subsequence on which complementary rational states occupy consecutive least refinement levels, \(N'-N=1\).

The computational component is fully reproducible and deliberately separated from the proofs. A direct reduced-fraction generator independently audits the structural classification through \(N\le 10^6\) and proves the finite first-collision claim by an explicit completeness bound. A separate core-bounded scan is exploratory and is not used to justify any theorem. The accompanying data and code are publicly archived at https://doi.org/10.5281/zenodo.22003359.

This combination of exact experiments, independently checkable computation, and formal arithmetic structure is why I believe the manuscript fits the journal’s emphasis on rigorous results inspired and tested by experimentation.

The manuscript is not under consideration elsewhere. The author reports no competing interests. The use of OpenAI ChatGPT and Codex during manuscript preparation and reproducibility work is disclosed in the manuscript in accordance with the publisher’s policy; I have checked the complete mathematical content, code, computations, and references and take full responsibility for them.

Thank you for considering the manuscript.

Warmth,

Jorge Rosales Pérez  
Independent Researcher  
Mérida, Yucatán, Mexico  
ORCID: 0009-0008-1679-7858  
mtro.jrp@gmail.com
